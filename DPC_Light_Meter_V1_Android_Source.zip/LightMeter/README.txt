DPC LIGHT METER V1.0
- Đọc cảm biến ánh sáng TYPE_LIGHT của điện thoại theo thời gian thực.
- Hiển thị lux, phân loại tham khảo, giá trị thấp nhất/cao nhất.
- Không yêu cầu quyền camera.
- Nếu điện thoại không có TYPE_LIGHT, app sẽ báo rõ.
Lưu ý: cảm biến điện thoại phù hợp khảo sát nhanh; đo nghiệm thu/đối chiếu tiêu chuẩn nên dùng lux meter đã hiệu chuẩn.
