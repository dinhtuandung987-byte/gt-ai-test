package com.dpc.lightmeter

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var lightSensor: Sensor? = null

    private lateinit var tvLux: TextView
    private lateinit var tvLabel: TextView
    private lateinit var tvMin: TextView
    private lateinit var tvMax: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnReset: Button

    private var minLux: Float? = null
    private var maxLux: Float? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvLux = findViewById(R.id.tvLux)
        tvLabel = findViewById(R.id.tvLabel)
        tvMin = findViewById(R.id.tvMin)
        tvMax = findViewById(R.id.tvMax)
        tvStatus = findViewById(R.id.tvStatus)
        btnReset = findViewById(R.id.btnReset)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)

        if (lightSensor == null) {
            tvStatus.text = "Máy này không có cảm biến ánh sáng (TYPE_LIGHT)."
            tvLux.text = "—"
            btnReset.isEnabled = false
        } else {
            tvStatus.text = "Đang đọc cảm biến…"
        }

        btnReset.setOnClickListener {
            minLux = null
            maxLux = null
            updateMinMaxLabels()
        }

        updateMinMaxLabels()
    }

    override fun onResume() {
        super.onResume()
        lightSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_LIGHT) return
        val lux = event.values[0]

        tvLux.text = formatLux(lux)
        tvLabel.text = classify(lux)
        tvStatus.text = "Đang đọc cảm biến…"

        if (minLux == null || lux < minLux!!) minLux = lux
        if (maxLux == null || lux > maxLux!!) maxLux = lux
        updateMinMaxLabels()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Không cần xử lý cho cảm biến ánh sáng
    }

    private fun formatLux(lux: Float): String {
        return if (lux >= 1000f) String.format("%.0f lux", lux)
        else String.format("%.1f lux", lux)
    }

    private fun updateMinMaxLabels() {
        tvMin.text = "Thấp nhất: " + (minLux?.let { formatLux(it) } ?: "—")
        tvMax.text = "Cao nhất: " + (maxLux?.let { formatLux(it) } ?: "—")
    }

    /**
     * Phân loại tham khảo (KHÔNG phải trích dẫn tiêu chuẩn TCVN cụ thể).
     * Chỉnh lại các mốc lux ở đây nếu bạn muốn đối chiếu theo tiêu chuẩn
     * chiếu sáng nơi làm việc thực tế (ví dụ TCVN 7114).
     */
    private fun classify(lux: Float): String = when {
        lux < 20 -> "Rất tối"
        lux < 100 -> "Tối"
        lux < 300 -> "Ánh sáng yếu"
        lux < 750 -> "Đủ sáng (văn phòng/xưởng thường)"
        lux < 2000 -> "Sáng (khu vực thao tác chi tiết)"
        lux < 10000 -> "Rất sáng"
        else -> "Chói (ngoài trời nắng)"
    }
}
