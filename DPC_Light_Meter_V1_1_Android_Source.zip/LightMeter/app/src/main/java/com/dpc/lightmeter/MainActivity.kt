package com.dpc.lightmeter

import android.app.Activity
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var lightSensor: Sensor? = null
    private lateinit var tvLux: TextView
    private lateinit var tvLevel: TextView
    private lateinit var tvMinMax: TextView
    private lateinit var tvStatus: TextView
    private var minLux = Float.POSITIVE_INFINITY
    private var maxLux = Float.NEGATIVE_INFINITY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvLux = findViewById(R.id.tvLux)
        tvLevel = findViewById(R.id.tvLevel)
        tvMinMax = findViewById(R.id.tvMinMax)
        tvStatus = findViewById(R.id.tvStatus)
        findViewById<Button>(R.id.btnReset).setOnClickListener { resetSession() }
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)
        if (lightSensor == null) {
            tvStatus.text = "Điện thoại này không có cảm biến ánh sáng (TYPE_LIGHT)."
            tvLux.text = "Không hỗ trợ"
            tvLevel.text = "Không thể đo Lux bằng cảm biến máy"
        } else {
            tvStatus.text = "Cảm biến ánh sáng: sẵn sàng"
        }
    }

    override fun onResume() {
        super.onResume()
        lightSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_LIGHT || event.values.isEmpty()) return
        val lux = event.values[0]
        if (!lux.isFinite()) return
        minLux = minOf(minLux, lux)
        maxLux = maxOf(maxLux, lux)
        tvLux.text = String.format(Locale.getDefault(), "%.0f lux", lux)
        tvLevel.text = when {
            lux < 100f -> "Ánh sáng rất thấp"
            lux < 300f -> "Ánh sáng thấp"
            lux < 500f -> "Ánh sáng trung bình"
            lux < 1000f -> "Ánh sáng tốt"
            else -> "Ánh sáng cao"
        }
        tvMinMax.text = String.format(Locale.getDefault(), "Min: %.0f lux   |   Max: %.0f lux", minLux, maxLux)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun resetSession() {
        minLux = Float.POSITIVE_INFINITY
        maxLux = Float.NEGATIVE_INFINITY
        tvMinMax.text = "Min: --   |   Max: --"
        tvLevel.text = "Đã đặt lại phiên đo"
    }
}
