package com.giatan.dpcdaily
import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.provider.Settings
import android.view.View
import android.widget.*
import org.json.*
import java.text.SimpleDateFormat
import java.util.*

data class Task(val id:Int,val code:String,val title:String,val area:String,val owner:String,val note:String,val whenMs:Long,var done:Boolean=false)

class MainActivity: Activity(){
 lateinit var code:EditText; lateinit var title:EditText; lateinit var area:EditText; lateinit var owner:EditText; lateinit var note:EditText
 lateinit var pick:Button; lateinit var list:LinearLayout; lateinit var status:TextView
 var whenMs=0L
 val prefs by lazy{getSharedPreferences("dpc_daily",MODE_PRIVATE)}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  code=findViewById(R.id.code);title=findViewById(R.id.title);area=findViewById(R.id.area);owner=findViewById(R.id.owner);note=findViewById(R.id.note);pick=findViewById(R.id.pick);list=findViewById(R.id.list);status=findViewById(R.id.status)
  createChannel(); requestNotify(); newCode(); render()
  pick.setOnClickListener{chooseDate()}
  findViewById<Button>(R.id.save).setOnClickListener{saveTask()}
 }
 fun requestNotify(){if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),100)}
 fun createChannel(){if(Build.VERSION.SDK_INT>=26){getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("cv_alert","Cảnh báo công việc",NotificationManager.IMPORTANCE_HIGH))}}
 fun tasks():MutableList<Task>{val a=mutableListOf<Task>();try{val j=JSONArray(prefs.getString("tasks","[]"));for(i in 0 until j.length()){val o=j.getJSONObject(i);a.add(Task(o.getInt("id"),o.getString("code"),o.getString("title"),o.optString("area"),o.optString("owner"),o.optString("note"),o.getLong("when"),o.optBoolean("done")))}}catch(_:Exception){};return a}
 fun persist(a:List<Task>){val j=JSONArray();a.forEach{t->j.put(JSONObject().put("id",t.id).put("code",t.code).put("title",t.title).put("area",t.area).put("owner",t.owner).put("note",t.note).put("when",t.whenMs).put("done",t.done))};prefs.edit().putString("tasks",j.toString()).apply()}
 fun newCode(){val n=prefs.getInt("seq",0)+1;code.setText("CV-${Calendar.getInstance().get(Calendar.YEAR)}-${"%04d".format(n)}")}
 fun chooseDate(){val c=Calendar.getInstance();DatePickerDialog(this,{_,y,m,d->TimePickerDialog(this,{_,h,min->c.set(y,m,d,h,min,0);whenMs=c.timeInMillis;pick.text=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi")).format(c.time)},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show()},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()}
 fun saveTask(){if(title.text.toString().trim().isEmpty()){Toast.makeText(this,"Nhập tên công việc",Toast.LENGTH_SHORT).show();return};if(whenMs==0L){Toast.makeText(this,"Chọn ngày giờ cảnh báo",Toast.LENGTH_SHORT).show();return}
  val seq=prefs.getInt("seq",0)+1;val c="CV-${Calendar.getInstance().get(Calendar.YEAR)}-${"%04d".format(seq)}";val id=(System.currentTimeMillis()%Int.MAX_VALUE).toInt()
  val a=tasks();val t=Task(id,c,title.text.toString().trim(),area.text.toString().trim(),owner.text.toString().trim(),note.text.toString().trim(),whenMs);a.add(0,t);persist(a);prefs.edit().putInt("seq",seq).apply();schedule(t)
  Toast.makeText(this,"Đã lưu $c và đặt cảnh báo",Toast.LENGTH_LONG).show();title.setText("");area.setText("");owner.setText("");note.setText("");whenMs=0;pick.text="Chọn ngày giờ";newCode();render()
 }
 fun schedule(t:Task){val am=getSystemService(AlarmManager::class.java);if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));Toast.makeText(this,"Cho phép Báo thức & lời nhắc, sau đó mở lại CV để đặt cảnh báo.",Toast.LENGTH_LONG).show();return}
  val i=Intent(this,AlarmReceiver::class.java).putExtra("code",t.code).putExtra("title",t.title);val pi=PendingIntent.getBroadcast(this,t.id,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.whenMs,pi)}
 fun render(){list.removeAllViews();val f=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi"));tasks().forEach{t->val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(12,12,12,12);val tv=TextView(this);tv.text="${t.code} — ${t.title}\n${if(t.area.isBlank())"" else t.area+" • "}${f.format(Date(t.whenMs))}${if(t.done)" • HOÀN THÀNH" else ""}";tv.textSize=16f;box.addView(tv);if(!t.done){val b=Button(this);b.text="Hoàn thành";b.setOnClickListener{val a=tasks();a.find{x->x.id==t.id}?.done=true;persist(a);getSystemService(AlarmManager::class.java).cancel(PendingIntent.getBroadcast(this,t.id,Intent(this,AlarmReceiver::class.java),PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE));render()};box.addView(b)};list.addView(box)};status.text="Đã lưu ${tasks().size} CV • Cảnh báo hoạt động độc lập khi app đóng"}
}
