package com.giatan.dpcdaily
import android.content.*
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){/* V3.0 lưu dữ liệu bền; V3.1 sẽ tự lên lịch lại toàn bộ CV sau reboot. */}}