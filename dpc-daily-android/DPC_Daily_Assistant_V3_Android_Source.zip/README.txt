DPC Daily Assistant V3 Android
- App Android độc lập, không cần web.
- Lưu công việc cục bộ trên điện thoại.
- Mã CV riêng: CV-YYYY-0001...
- Đặt ngày + giờ cảnh báo.
- Android notification khi app đã đóng.
- GT System không bị thay đổi.
- Android 13+ cần cho phép Notifications.
- Android 12+ cần cho phép Alarms & reminders để cảnh báo đúng giờ.
- Đây là source project Android Studio. Môi trường hiện tại không có Android SDK/Gradle nên chưa thể xuất APK trực tiếp.
