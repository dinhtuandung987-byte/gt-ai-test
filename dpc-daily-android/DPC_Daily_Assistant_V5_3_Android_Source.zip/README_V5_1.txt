DPC Daily Assistant V5.1

Nâng cấp từ V5.0:
- Tự sinh báo cáo offline từ dữ liệu công việc.
- Báo cáo gồm: thông tin CV, nội dung thực hiện, thông số/ghi nhận, kết quả, số ảnh minh chứng, trạng thái.
- Xem trước báo cáo trong app.
- Tạo lại báo cáo sau khi sửa dữ liệu.
- Chia sẻ báo cáo dạng văn bản qua các ứng dụng Android.
- Giữ tương thích dữ liệu V4.1/V5.0; thêm trường generatedReport với giá trị mặc định rỗng.
- Chưa dùng API AI: đây là bộ sinh báo cáo theo mẫu để hoạt động offline.

Luồng: THỰC HIỆN CV -> nhập thông số/kết quả + ảnh -> TẠO BÁO CÁO TỰ ĐỘNG -> xem/kiểm tra -> chia sẻ/hoàn thành.
