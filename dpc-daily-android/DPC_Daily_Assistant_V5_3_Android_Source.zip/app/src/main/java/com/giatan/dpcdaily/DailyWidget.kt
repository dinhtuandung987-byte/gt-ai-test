package com.giatan.dpcdaily

import android.app.*
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.graphics.Color
import android.widget.RemoteViews
import java.util.concurrent.TimeUnit
import java.text.SimpleDateFormat
import java.util.*

class DailyWidget:AppWidgetProvider(){
    override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){ ids.forEach{update(c,m,it)} }
    override fun onEnabled(c:Context){ StatusNotifier.update(c) }
    companion object{
        fun updateAll(c:Context){val m=AppWidgetManager.getInstance(c);m.getAppWidgetIds(ComponentName(c,DailyWidget::class.java)).forEach{update(c,m,it)}}
        private fun update(c:Context,m:AppWidgetManager,id:Int){
            val cnt=StatusNotifier.counts(c); val pending=cnt[0]+cnt[1]+cnt[2]
            val dpc=StatusNotifier.counts(c,"DPC"); val gt=StatusNotifier.counts(c,"Gia Tân")
            val tasks=TaskStore.tasks(c).filter{!it.done}.sortedWith(compareBy<Task>{it.whenMs}.thenBy{it.code})
            fun groupText(group:String):String{
                val a=tasks.filter{it.group==group}; if(a.isEmpty()) return "✓ Không có CV đang chờ"
                val shown=a.take(2).map{t->"• ${t.code} · ${t.title} · ${shortRemaining(t.whenMs)}"}.toMutableList()
                if(a.size>2) shown.add("+ ${a.size-2} CV khác")
                return shown.joinToString("\n")
            }
            val v=RemoteViews(c.packageName,R.layout.widget_daily)
            v.setTextViewText(R.id.w_overdue,"${cnt[0]}\nQuá hạn"); v.setTextViewText(R.id.w_today,"${cnt[1]}\nHôm nay"); v.setTextViewText(R.id.w_upcoming,"${cnt[2]}\nSắp tới"); v.setTextViewText(R.id.w_done,"${cnt[3]}\nHoàn thành")
            v.setTextViewText(R.id.w_total,"Còn $pending CV")
            v.setTextViewText(R.id.w_groups,"DPC ${dpc[0]+dpc[1]+dpc[2]} CV   •   GIA TÂN ${gt[0]+gt[1]+gt[2]} CV")
            val total=pending+cnt[3]; val progress=if(total==0)0 else cnt[3]*100/total
            v.setProgressBar(R.id.w_progress,100,progress,false); v.setTextViewText(R.id.w_progress_text,"Tiến độ $progress%")
            v.setTextViewText(R.id.w_updated,"Cập nhật "+SimpleDateFormat("HH:mm",Locale("vi")).format(Date()))
            v.setTextViewText(R.id.w_dpc_tasks,groupText("DPC")); v.setTextViewText(R.id.w_gt_tasks,groupText("Gia Tân"))
            val pi=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.widget_root,pi); m.updateAppWidget(id,v)
        }
        private fun shortRemaining(ms:Long):String{
            val d=ms-System.currentTimeMillis(); val a=kotlin.math.abs(d); val days=a/86400000; val hours=(a%86400000)/3600000
            val txt=if(days>0)"${days}n ${hours}h" else "${hours}h"
            return if(d<0)"quá hạn $txt" else "còn $txt"
        }
    }
}
