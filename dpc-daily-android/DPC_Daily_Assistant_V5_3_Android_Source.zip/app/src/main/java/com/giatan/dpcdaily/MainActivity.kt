package com.giatan.dpcdaily
import android.Manifest
import android.app.*
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.widget.*
import android.graphics.Rect
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity:Activity(){
 private var pendingPhotoTaskId:Int?=null
 private var pendingBackupContent:String?=null
 lateinit var code:EditText;lateinit var title:EditText;lateinit var area:EditText;lateinit var owner:EditText;lateinit var note:EditText;lateinit var pick:Button;lateinit var list:LinearLayout;lateinit var homeList:LinearLayout;lateinit var status:TextView;lateinit var group:Spinner;lateinit var showDone:CheckBox; var selectedGroup="DPC"
 var whenMs=0L;var filter="ALL";var selectedPriority="Trung bình";val prefs by lazy{TaskStore.prefs(this)}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  code=findViewById(R.id.code);title=findViewById(R.id.title);area=findViewById(R.id.area);owner=findViewById(R.id.owner);note=findViewById(R.id.note);pick=findViewById(R.id.pick);list=findViewById(R.id.list);status=findViewById(R.id.status);group=findViewById(R.id.group);showDone=findViewById(R.id.show_done)
  group.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("DPC","Gia Tân"));homeList=findViewById(R.id.home_list);StatusNotifier.createChannels(this);requestNotify();newCode();setupNavigation();selectGroup("DPC");render();StatusNotifier.update(this)
  setupKeyboardSafeUi();pick.setOnClickListener{chooseDate()};findViewById<Button>(R.id.save).setOnClickListener{saveTask()};showDone.setOnCheckedChangeListener{_,_->render()}
  findViewById<Button>(R.id.filter_all).setOnClickListener{filter="ALL";render()};findViewById<Button>(R.id.filter_dpc).setOnClickListener{filter="DPC";render()};findViewById<Button>(R.id.filter_gt).setOnClickListener{filter="Gia Tân";render()};findViewById<Button>(R.id.group_dpc).setOnClickListener{selectGroup("DPC")};findViewById<Button>(R.id.group_gt).setOnClickListener{selectGroup("Gia Tân")};findViewById<Button>(R.id.priority_high).setOnClickListener{selectPriority("Cao")};findViewById<Button>(R.id.priority_medium).setOnClickListener{selectPriority("Trung bình")};findViewById<Button>(R.id.priority_low).setOnClickListener{selectPriority("Thấp")};selectPriority("Trung bình");findViewById<Button>(R.id.delete_done).setOnClickListener{deleteCompleted()};findViewById<Button>(R.id.add_widget).setOnClickListener{requestHomeWidget()};offerWidgetOnce();findViewById<Button>(R.id.backup_export).setOnClickListener{exportBackup()};findViewById<Button>(R.id.backup_import).setOnClickListener{importBackup()}
 }
 override fun onResume(){super.onResume();render();StatusNotifier.update(this)}
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
  super.onActivityResult(requestCode,resultCode,data)
  if(requestCode==501 && resultCode==RESULT_OK){
   val id=pendingPhotoTaskId?:return; val a=TaskStore.tasks(this); val t=a.find{it.id==id}?:return
   val uris=mutableListOf<Uri>(); data?.clipData?.let{c->for(i in 0 until c.itemCount)uris.add(c.getItemAt(i).uri)} ?: data?.data?.let{uris.add(it)}
   uris.forEach{u->try{contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};if(!t.photoUris.contains(u.toString()))t.photoUris.add(u.toString())}
   TaskStore.persist(this,a); pendingPhotoTaskId=null; openWork(t.id)
  }
  if(requestCode==502 && resultCode==RESULT_OK){
   val uri=data?.data?:return; val content=pendingBackupContent?:return
   try{
    contentResolver.openOutputStream(uri)?.use{os->os.write(content.toByteArray(Charsets.UTF_8))}
    Toast.makeText(this,"Đã xuất file sao lưu.",Toast.LENGTH_LONG).show()
   }catch(e:Exception){Toast.makeText(this,"Lỗi ghi file: ${e.message}",Toast.LENGTH_LONG).show()}
   pendingBackupContent=null
  }
  if(requestCode==503 && resultCode==RESULT_OK){
   val uri=data?.data?:return
   try{
    val text=contentResolver.openInputStream(uri)?.use{ins->BufferedReader(InputStreamReader(ins,Charsets.UTF_8)).readText()}?:""
    confirmRestore(text)
   }catch(e:Exception){Toast.makeText(this,"Lỗi đọc file: ${e.message}",Toast.LENGTH_LONG).show()}
  }
 }

 fun inferType(t:Task):String{val x=(t.title+" "+t.area+" "+t.note).lowercase(Locale.getDefault());return when{listOf("tủ điện","điện","cb","mccb").any{x.contains(it)}->"Điện / Tủ điện";listOf("máy phát","ats").any{x.contains(it)}->"Máy phát / ATS";listOf("nước","bơm","phao").any{x.contains(it)}->"Nước / Bơm";listOf("pm","bảo trì","máy may").any{x.contains(it)}->"PM / Máy";listOf("capa","finding","khắc phục").any{x.contains(it)}->"Finding / CAPA";else->"Công việc hiện trường"}}
 fun guideFor(t:Task):String{return when(inferType(t)){"Điện / Tủ điện"->"Ảnh cần: tổng thể tủ, bên trong, CB/đầu nối, nhãn và điểm bất thường.\nThông số: điện áp, dòng tải, nhiệt độ (nếu có), N/PE, dấu hiệu phát nhiệt/rò.";"Máy phát / ATS"->"Ảnh cần: máy phát, ATS/CB chuyển nguồn, màn hình thông số, đầu nối.\nThông số: điện áp, tần số, dòng/tải %, trạng thái chuyển nguồn và bất thường.";"Nước / Bơm"->"Ảnh cần: tổng thể, bơm/phao/van, đường ống và điểm đấu nối.\nThông số: trạng thái bơm, mực nước/áp suất (nếu có), rò rỉ và kết quả chạy thử.";"PM / Máy"->"Ảnh cần: mã máy, tổng thể, vị trí bảo trì và ảnh sau xử lý.\nThông số: tình trạng trước/sau, thông số kiểm tra, hạng mục thay thế.";"Finding / CAPA"->"Ảnh cần: hiện trạng trước xử lý, quá trình và sau xử lý.\nGhi: nguyên nhân xác định, hành động thực hiện, bằng chứng đóng.";else->"Ảnh cần: toàn cảnh, vị trí thực hiện, chi tiết bất thường và sau hoàn thành.\nGhi các thông số/khối lượng thực tế cần thiết."}}
 fun addPhotos(taskId:Int){pendingPhotoTaskId=taskId;val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)};startActivityForResult(i,501)}

 fun exportBackup(){
  try{
   val tasksJson=JSONArray(prefs.getString("tasks","[]"))
   val backup=JSONObject()
    .put("app","DPC Daily Assistant").put("exportedAt",System.currentTimeMillis())
    .put("exportedAtText",SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi")).format(Date()))
    .put("seq_dpc",prefs.getInt("seq_dpc",0)).put("seq_gt",prefs.getInt("seq_gt",0))
    .put("tasks",tasksJson)
   pendingBackupContent=backup.toString(2)
   val fname="DPC_Daily_Backup_"+SimpleDateFormat("yyyyMMdd_HHmm",Locale("vi")).format(Date())+".json"
   val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,fname)}
   startActivityForResult(i,502)
  }catch(e:Exception){Toast.makeText(this,"Lỗi tạo file sao lưu: ${e.message}",Toast.LENGTH_LONG).show()}
 }
 fun importBackup(){
  val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"}
  try{startActivityForResult(i,503)}catch(e:Exception){Toast.makeText(this,"Không mở được trình chọn file.",Toast.LENGTH_LONG).show()}
 }
 fun confirmRestore(text:String){
  val count=try{
   val o=JSONObject(text)
   (if(o.has("tasks")) o.getJSONArray("tasks") else JSONArray(text)).length()
  }catch(e:Exception){ try{JSONArray(text).length()}catch(e2:Exception){-1} }
  if(count<0){Toast.makeText(this,"File không đúng định dạng sao lưu DPC Daily.",Toast.LENGTH_LONG).show();return}
  AlertDialog.Builder(this).setTitle("Khôi phục dữ liệu?")
   .setMessage("File này có $count công việc.\nKHÔI PHỤC sẽ GHI ĐÈ toàn bộ công việc hiện có trên máy và không thể hoàn tác.\n\nTiếp tục?")
   .setNegativeButton("Hủy",null)
   .setPositiveButton("GHI ĐÈ & KHÔI PHỤC"){_,_->restoreFromBackupJson(text)}.show()
 }
 fun restoreFromBackupJson(text:String){
  try{
   val o=try{JSONObject(text)}catch(e:Exception){null}
   val tasksArr=if(o!=null && o.has("tasks")) o.getJSONArray("tasks") else JSONArray(text)
   TaskStore.tasks(this).forEach{cancel(it)}
   val ed=prefs.edit().putString("tasks",tasksArr.toString())
   if(o!=null){ if(o.has("seq_dpc"))ed.putInt("seq_dpc",o.optInt("seq_dpc",0)); if(o.has("seq_gt"))ed.putInt("seq_gt",o.optInt("seq_gt",0)) }
   ed.apply()
   rescheduleAll();render();StatusNotifier.update(this)
   Toast.makeText(this,"Đã khôi phục ${tasksArr.length()} công việc.",Toast.LENGTH_LONG).show()
  }catch(e:Exception){Toast.makeText(this,"Lỗi khôi phục: ${e.message}",Toast.LENGTH_LONG).show()}
 }
 fun rescheduleAll(){
  val am=getSystemService(AlarmManager::class.java); val canExact=Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms(); val now=System.currentTimeMillis()
  TaskStore.tasks(this).filter{!it.done&&it.whenMs>now}.forEach{t->
   val i=Intent(this,AlarmReceiver::class.java).putExtra("code",t.code).putExtra("title",t.title).putExtra("group",t.group).putExtra("area",t.area)
   val pi=PendingIntent.getBroadcast(this,t.id,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
   if(canExact) try{am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.whenMs,pi)}catch(_:Exception){}
  }
  if(!canExact){Toast.makeText(this,"Đã khôi phục dữ liệu. Hãy bật quyền Báo thức & lời nhắc để cảnh báo hoạt động lại.",Toast.LENGTH_LONG).show();startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))}
 }
 fun openTaskDetail(taskId:Int){
  val t=TaskStore.tasks(this).find{it.id==taskId}?:return
  val f=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi"))
  val wrap=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(4),dp(16),0)}
  fun addLine(label:String,value:String){
   val v=TextView(this).apply{text="$label\n${if(value.isBlank()) "—" else value}";textSize=14f;setTextColor(Color.rgb(37,54,74));setPadding(0,dp(5),0,dp(7));setTextIsSelectable(true)}
   wrap.addView(v)
  }
  addLine("Mã công việc",t.code+" • "+t.group)
  addLine("Công việc",t.title)
  addLine("Khu vực",t.area)
  addLine("Người phụ trách",t.owner)
  addLine("Ghi chú / Yêu cầu",t.note)
  addLine("Thời hạn",f.format(Date(t.whenMs))+" • Ưu tiên "+t.priority)
  addLine("Loại công việc",inferType(t))
  if(t.parameters.isNotBlank()) addLine("Dữ liệu / Thông số hiện trường",t.parameters)
  if(t.result.isNotBlank()) addLine("Xử lý / Kết quả",t.result)
  addLine("Ảnh minh chứng","${t.photoUris.size} ảnh")
  addLine("Trạng thái",if(t.done) "Đã hoàn thành" else remainingText(t.whenMs))
  val dlg=AlertDialog.Builder(this).setTitle("CHI TIẾT CÔNG VIỆC").setView(wrap).setNegativeButton("Đóng",null)
  if(t.generatedReport.isNotBlank()) dlg.setNeutralButton("XEM BÁO CÁO"){_,_->showReport(t.id)}
  if(!t.done) dlg.setPositiveButton("THỰC HIỆN CV"){_,_->openWork(t.id)}
  dlg.show()
 }
 fun openWork(taskId:Int){
  val t=TaskStore.tasks(this).find{it.id==taskId}?:return; val wrap=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(4),dp(16),0)}
  val guide=TextView(this).apply{text="${t.code} • ${inferType(t)}\n\n${guideFor(t)}\n\nẢnh đã lưu: ${t.photoUris.size}";textSize=14f;setTextColor(Color.rgb(37,54,74));setPadding(0,0,0,dp(8))};wrap.addView(guide)
  val param=EditText(this).apply{hint="DỮ LIỆU THỰC TẾ: số đo, trạng thái, vị trí, thời điểm, tải vận hành...\nVD: L1/L2/L3=18/23/20A; U=398/401/399V; cos L2=52°C";minLines=4;gravity=android.view.Gravity.TOP;setText(t.parameters)};wrap.addView(param)
  val result=EditText(this).apply{hint="XỬ LÝ THỰC TẾ / KẾT QUẢ SAU XỬ LÝ (nếu có). Không cần tự kết luận nguyên nhân.";minLines=4;gravity=android.view.Gravity.TOP;setText(t.result)};wrap.addView(result)
  val reportBtn=Button(this).apply{text="⚙ PHÂN TÍCH & TẠO BÁO CÁO KỸ THUẬT";isAllCaps=false};wrap.addView(reportBtn)
  if(t.generatedReport.isNotBlank()){val viewReport=Button(this).apply{text="📄 XEM / CHIA SẺ BÁO CÁO";isAllCaps=false;setOnClickListener{saveExecution(t.id,param.text.toString(),result.text.toString(),false);showReport(t.id)}};wrap.addView(viewReport)}
  val photos=Button(this).apply{text="📷 THÊM ẢNH MINH CHỨNG (${t.photoUris.size})";isAllCaps=false};wrap.addView(photos)
  val dlg=AlertDialog.Builder(this).setTitle("THỰC HIỆN CÔNG VIỆC").setView(wrap).setNegativeButton("Đóng",null).setNeutralButton("Lưu"){_,_->saveExecution(t.id,param.text.toString(),result.text.toString(),false)}.setPositiveButton("HOÀN THÀNH"){_,_->saveExecution(t.id,param.text.toString(),result.text.toString(),true)}.create()
  reportBtn.setOnClickListener{saveExecution(t.id,param.text.toString(),result.text.toString(),false);dlg.dismiss();generateReport(t.id,param.text.toString(),result.text.toString())};photos.setOnClickListener{saveExecution(t.id,param.text.toString(),result.text.toString(),false);dlg.dismiss();addPhotos(t.id)};dlg.show()
 }
 fun technicalAssessment(t:Task,parameters:String,result:String):Triple<String,String,String>{
  val x=(t.title+" "+t.note+" "+parameters+" "+result).lowercase(Locale.getDefault())
  val assess=mutableListOf<String>(); val causes=mutableListOf<String>(); val actions=mutableListOf<String>()
  fun has(vararg k:String)=k.any{x.contains(it)}
  if(parameters.isBlank()) assess.add("Chưa có đủ số liệu đo/ghi nhận để thực hiện đánh giá kỹ thuật.")
  if(has("nóng","nhiệt","°c","khét")){
   assess.add("Có ghi nhận liên quan đến nhiệt độ/phát nhiệt. Chưa quy nguyên nhân nếu chưa đối chiếu tải, nhiệt độ các pha/vị trí tương đương và tình trạng tiếp xúc.")
   causes.add("Tiếp xúc điện, độ siết đầu nối, tải vận hành hoặc điều kiện tản nhiệt là các yếu tố cần kiểm tra; đây chưa phải nguyên nhân đã xác nhận.")
   actions.add("Đo so sánh nhiệt độ trong cùng điều kiện tải; kiểm tra đầu cos/mối nối, độ siết và bề mặt tiếp xúc; đo lại sau xử lý.")
  }
  if(has("rò","rò điện","cách điện","megger")){
   assess.add("Có dấu hiệu/dữ liệu liên quan đến cách điện hoặc dòng rò; cần số đo và điều kiện thử để kết luận mức độ.")
   causes.add("Có thể liên quan cách điện suy giảm, ẩm, dây/thiết bị hư hỏng hoặc tải phía sau; cần khoanh vùng từng nhánh.")
   actions.add("Cô lập từng nhánh, đo cách điện/dòng rò theo điều kiện phù hợp và kiểm tra lại sau khi xử lý.")
  }
  if(has("thất thoát","công tơ","điện năng")){
   assess.add("Chưa kết luận thất thoát điện chỉ từ mức tiêu thụ. Cần xác minh điện năng khi các tải đã được tắt/cô lập.")
   causes.add("Tải chờ/tải ẩn, nhánh chưa cô lập, rò điện hoặc sai khác đo đếm là các khả năng cần loại trừ lần lượt.")
   actions.add("Ghi chỉ số công tơ đầu-cuối trong thời gian cô lập tải; nếu vẫn phát sinh điện năng, ngắt từng CB nhánh và đo dòng để khoanh vùng.")
  }
  if(has("mất pha","lệch pha","l1","l2","l3")){
   assess.add("Các thông số pha cần được so sánh tại cùng thời điểm và cùng điều kiện vận hành; chênh lệch số đo không tự động đồng nghĩa quá tải hoặc sự cố.")
   actions.add("Đối chiếu điện áp/dòng L1-L2-L3 với tải thực tế, định mức thiết bị bảo vệ và dây dẫn trước khi kết luận.")
  }
  if(has("ats","máy phát","chuyển nguồn")){
   assess.add("Đánh giá chuyển nguồn cần dựa trên trạng thái nguồn, liên động, trình tự thao tác và kết quả thử tải thực tế.")
   actions.add("Kiểm tra liên động chống đóng đồng thời hai nguồn; ghi điện áp, tần số, dòng/tải và kết quả chuyển nguồn khi thử.")
  }
  if(has("bơm","nước","phao")){
   assess.add("Đánh giá hệ thống bơm/nước cần đối chiếu trạng thái vận hành với mực nước/áp suất, điều khiển phao và dấu hiệu rò rỉ thực tế.")
   actions.add("Chạy thử theo điều kiện thực tế, kiểm tra điều khiển/chống tràn và ghi nhận trạng thái trước-sau xử lý.")
  }
  if(assess.isEmpty()) assess.add("Dữ liệu hiện trường được ghi nhận làm cơ sở đánh giá. Chưa tự suy diễn nguyên nhân khi chưa có phép đo hoặc bằng chứng xác nhận.")
  if(causes.isEmpty()) causes.add("Chưa đủ dữ liệu để xác định nguyên nhân. Cần kiểm tra/đo bổ sung nếu hiện trạng còn bất thường.")
  if(actions.isEmpty()) actions.add("Đối chiếu hiện trạng, thông số đo và điều kiện vận hành; bổ sung phép đo cần thiết trước khi đưa ra kết luận cuối cùng.")
  return Triple(assess.joinToString("\n- ","- "),causes.joinToString("\n- ","- "),actions.distinct().joinToString("\n- ","- "))
 }
 fun buildReport(t:Task,parameters:String,result:String):String{
  val date=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi")).format(Date())
  val due=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi")).format(Date(t.whenMs))
  val params=if(parameters.trim().isBlank()) "Chưa ghi nhận thông số/số đo." else parameters.trim()
  val actual=if(result.trim().isBlank()) "Chưa ghi nhận xử lý/kết quả sau xử lý." else result.trim()
  val (assessment,causes,actions)=technicalAssessment(t,parameters,result)
  val evidence=if(t.photoUris.isEmpty()) "Chưa có ảnh minh chứng trong hồ sơ." else "Có ${t.photoUris.size} ảnh minh chứng trong hồ sơ công việc."
  val confidence=when{parameters.isBlank()&&t.photoUris.isEmpty()->"Dữ liệu chưa đủ – chưa kết luận";parameters.isBlank()->"Có ảnh nhưng thiếu số liệu – cần xác minh";else->"Có dữ liệu hiện trường – kết luận cuối cùng vẫn cần người thực hiện xác nhận"}
  return """BÁO CÁO KẾT QUẢ / PHÂN TÍCH KỸ THUẬT

Mã công việc: ${t.code}
Nhóm: ${t.group}
Công việc: ${t.title}
Khu vực: ${if(t.area.isBlank()) "—" else t.area}
Người phụ trách: ${if(t.owner.isBlank()) "—" else t.owner}
Loại công việc: ${inferType(t)}
Thời hạn: $due
Thời điểm lập: $date

1. NỘI DUNG THỰC HIỆN
${t.title}${if(t.note.isBlank()) "" else "\nKế hoạch/ghi chú: ${t.note}"}

2. DỮ LIỆU THỰC TẾ / THÔNG SỐ ĐO
$params

3. ĐÁNH GIÁ KỸ THUẬT
$assessment

4. NGUYÊN NHÂN KHẢ DĨ / ĐIỂM CẦN XÁC MINH
$causes

5. XỬ LÝ THỰC TẾ / KẾT QUẢ SAU XỬ LÝ
$actual

6. ĐỀ XUẤT KIỂM TRA / KHẮC PHỤC
$actions

7. HÌNH ẢNH MINH CHỨNG
$evidence

8. MỨC ĐỘ CƠ SỞ KẾT LUẬN
$confidence

9. TRẠNG THÁI
${if(t.done) "Đã hoàn thành" else "Đang thực hiện / chờ xác nhận"}

Nguyên tắc báo cáo: Tách dữ liệu thực tế khỏi đánh giá; không tự quy nguyên nhân; không dùng số liệu chưa nhập; không kết luận Đạt/Không đạt khi chưa có tiêu chí đối chiếu. Người thực hiện kiểm tra và xác nhận trước khi chia sẻ."""
 }
 fun generateReport(id:Int,parameters:String,result:String){
  val a=TaskStore.tasks(this);val t=a.find{it.id==id}?:return
  t.workType=inferType(t);t.parameters=parameters.trim();t.result=result.trim();t.generatedReport=buildReport(t,t.parameters,t.result);TaskStore.persist(this,a);showReport(t.id)
 }
 fun showReport(id:Int){
  val t=TaskStore.tasks(this).find{it.id==id}?:return
  val report=if(t.generatedReport.isBlank()) buildReport(t,t.parameters,t.result) else t.generatedReport
  val tv=TextView(this).apply{text=report;textSize=14f;setTextColor(Color.rgb(37,54,74));setPadding(dp(16),dp(8),dp(16),dp(12));setTextIsSelectable(true)}
  val sc=ScrollView(this).apply{addView(tv)}
  AlertDialog.Builder(this).setTitle("BÁO CÁO • ${t.code}").setView(sc).setNegativeButton("Đóng",null).setNeutralButton("Tạo lại"){_,_->generateReport(t.id,t.parameters,t.result)}.setPositiveButton("CHIA SẺ"){_,_->shareReport(t,report)}.show()
 }
 fun shareReport(t:Task,report:String){
  val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"Báo cáo ${t.code} - ${t.title}");putExtra(Intent.EXTRA_TEXT,report)}
  startActivity(Intent.createChooser(i,"Chia sẻ báo cáo"))
 }
 fun saveExecution(id:Int,parameters:String,result:String,finish:Boolean){val a=TaskStore.tasks(this);val t=a.find{it.id==id}?:return;t.workType=inferType(t);t.parameters=parameters.trim();t.result=result.trim();if(finish){t.done=true;cancel(t)};TaskStore.persist(this,a);render();StatusNotifier.update(this)}

 fun requestHomeWidget(){
  val awm=AppWidgetManager.getInstance(this)
  val provider=ComponentName(this,DailyWidget::class.java)
  if(Build.VERSION.SDK_INT>=26 && awm.isRequestPinAppWidgetSupported){
   val ok=awm.requestPinAppWidget(provider,null,null)
   if(!ok) Toast.makeText(this,"Mở mục Widget của màn hình chính và chọn DPC Daily Assistant.",Toast.LENGTH_LONG).show()
  }else Toast.makeText(this,"Nhấn giữ màn hình chính → Widget → DPC Daily Assistant.",Toast.LENGTH_LONG).show()
 }
 fun offerWidgetOnce(){
  val key="widget_offer_v38"
  if(!prefs.getBoolean(key,false)){
   prefs.edit().putBoolean(key,true).apply()
   AlertDialog.Builder(this).setTitle("Đưa DPC Daily ra màn hình chính")
    .setMessage("V3.8 có bảng Widget lớn đúng mẫu: 4 trạng thái, tổng CV, tiến độ và công việc ưu tiên. Android cần anh xác nhận một lần để đặt Widget lên màn hình chính.")
    .setNegativeButton("Để sau",null).setPositiveButton("THÊM WIDGET"){_,_->requestHomeWidget()}.show()
  }
 }

 fun setupKeyboardSafeUi(){
  window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
  val root=findViewById<View>(R.id.root_layout);val nav=findViewById<View>(R.id.bottom_nav);val create=findViewById<ScrollView>(R.id.page_create)
  if(Build.VERSION.SDK_INT>=23){
   root.setOnApplyWindowInsetsListener{_,ins->
    val bottom=if(Build.VERSION.SDK_INT>=30) ins.getInsets(WindowInsets.Type.navigationBars()).bottom else ins.systemWindowInsetBottom
    nav.setPadding(nav.paddingLeft,nav.paddingTop,nav.paddingRight,bottom+6)
    nav.layoutParams.height=resources.displayMetrics.density.times(58).toInt()+bottom
    ins
   }
  }
  fun reveal(v:View){ create.postDelayed({
    val r=Rect();v.getDrawingRect(r);create.offsetDescendantRectToMyCoords(v,r);r.bottom+=resources.displayMetrics.density.times(160).toInt();create.requestChildRectangleOnScreen(v,r,true)
   },180) }
  root.viewTreeObserver.addOnGlobalLayoutListener{
   val r=Rect();root.getWindowVisibleDisplayFrame(r);val keyboard=root.rootView.height-r.bottom;val open=keyboard>root.rootView.height*0.15
   nav.visibility=if(open) View.GONE else View.VISIBLE
   if(open) currentFocus?.let{reveal(it)}
  }
  listOf(title,area,owner,note).forEach{v->v.setOnFocusChangeListener{view,has->if(has)reveal(view)}}
 }
 fun setupNavigation(){
  val pages=listOf(findViewById<android.view.View>(R.id.page_home),findViewById(R.id.page_create),findViewById(R.id.page_list),findViewById(R.id.page_stats),findViewById(R.id.page_settings))
  fun show(i:Int){pages.forEachIndexed{n,v->v.visibility=if(n==i)android.view.View.VISIBLE else android.view.View.GONE};render()}
  findViewById<Button>(R.id.nav_home).setOnClickListener{show(0)};findViewById<Button>(R.id.nav_create).setOnClickListener{show(1)};findViewById<Button>(R.id.nav_list).setOnClickListener{show(2)};findViewById<Button>(R.id.nav_stats).setOnClickListener{show(3)};findViewById<Button>(R.id.nav_settings).setOnClickListener{show(4)}
 }
 fun selectGroup(g:String){selectedGroup=g;group.setSelection(if(g=="DPC")0 else 1);newCode();val d=findViewById<Button>(R.id.group_dpc);val gt=findViewById<Button>(R.id.group_gt);val hint=findViewById<TextView>(R.id.group_hint);if(g=="DPC"){d.setBackgroundColor(Color.rgb(10,116,230));d.setTextColor(Color.WHITE);gt.setBackgroundColor(Color.rgb(235,238,242));gt.setTextColor(Color.DKGRAY);hint.text="DPC • An toàn • Ổn định • Hiệu quả";hint.setTextColor(Color.rgb(11,95,158))}else{gt.setBackgroundColor(Color.rgb(36,145,72));gt.setTextColor(Color.WHITE);d.setBackgroundColor(Color.rgb(235,238,242));d.setTextColor(Color.DKGRAY);hint.text="GIA TÂN • Điện nước • Máy móc • Dịch vụ tận tâm";hint.setTextColor(Color.rgb(36,125,62))}}

 fun selectPriority(p:String){selectedPriority=p;val hi=findViewById<Button>(R.id.priority_high);val med=findViewById<Button>(R.id.priority_medium);val low=findViewById<Button>(R.id.priority_low);listOf(hi,med,low).forEach{it.setTextColor(Color.DKGRAY);it.setBackgroundColor(Color.rgb(235,238,242))};when(p){"Cao"->{hi.setBackgroundColor(Color.rgb(210,40,40));hi.setTextColor(Color.WHITE)};"Thấp"->{low.setBackgroundColor(Color.rgb(36,145,72));low.setTextColor(Color.WHITE)};else->{med.setBackgroundColor(Color.rgb(238,145,25));med.setTextColor(Color.WHITE)}}}
 fun remainingText(ms:Long):String{val d=ms-System.currentTimeMillis();val a=kotlin.math.abs(d);val days=a/86400000;val hours=(a%86400000)/3600000;val mins=(a%3600000)/60000;val txt=if(days>0)"${days} ngày ${hours}h" else if(hours>0)"${hours}h ${mins}′" else "${mins} phút";return if(d<0)"Quá hạn $txt" else "Còn $txt"}
 fun requestNotify(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),100)}
 fun groupPrefix(g:String)=if(g=="Gia Tân")"GT" else "DPC"
 fun nextGroupSeq(g:String):Int{
  val prefix=groupPrefix(g)+"-${Calendar.getInstance().get(Calendar.YEAR)}-"
  val fromTasks=TaskStore.tasks(this).mapNotNull{t->if(t.code.startsWith(prefix))t.code.removePrefix(prefix).toIntOrNull() else null}.maxOrNull()?:0
  val key=if(g=="Gia Tân")"seq_gt" else "seq_dpc"
  return maxOf(fromTasks,prefs.getInt(key,0))+1
 }
 fun newCode(){val n=nextGroupSeq(selectedGroup);code.setText("${groupPrefix(selectedGroup)}-${Calendar.getInstance().get(Calendar.YEAR)}-${"%04d".format(n)}")}
 fun chooseDate(){val c=Calendar.getInstance();DatePickerDialog(this,{_,y,m,d->TimePickerDialog(this,{_,h,min->c.set(y,m,d,h,min,0);whenMs=c.timeInMillis;pick.text=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi")).format(c.time)},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show()},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()}
 fun saveTask(){if(title.text.toString().trim().isEmpty()){Toast.makeText(this,"Nhập tên công việc",Toast.LENGTH_SHORT).show();return};if(whenMs==0L){Toast.makeText(this,"Chọn ngày giờ cảnh báo",Toast.LENGTH_SHORT).show();return};val seq=nextGroupSeq(selectedGroup);val c="${groupPrefix(selectedGroup)}-${Calendar.getInstance().get(Calendar.YEAR)}-${"%04d".format(seq)}";val id=(System.currentTimeMillis()%Int.MAX_VALUE).toInt();val a=TaskStore.tasks(this);val t=Task(id,c,selectedGroup,title.text.toString().trim(),area.text.toString().trim(),owner.text.toString().trim(),note.text.toString().trim(),whenMs,false,selectedPriority);a.add(0,t);TaskStore.persist(this,a);val key=if(selectedGroup=="Gia Tân")"seq_gt" else "seq_dpc";prefs.edit().putInt(key,seq).apply();schedule(t);Toast.makeText(this,"Đã lưu $c",Toast.LENGTH_LONG).show();title.setText("");area.setText("");owner.setText("");note.setText("");whenMs=0;pick.text="Chọn ngày giờ";selectPriority("Trung bình");newCode();render();StatusNotifier.update(this)}
 fun schedule(t:Task){val am=getSystemService(AlarmManager::class.java);if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));Toast.makeText(this,"Hãy bật quyền Báo thức & lời nhắc.",Toast.LENGTH_LONG).show();return};val i=Intent(this,AlarmReceiver::class.java).putExtra("code",t.code).putExtra("title",t.title).putExtra("group",t.group).putExtra("area",t.area);val pi=PendingIntent.getBroadcast(this,t.id,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.whenMs,pi)}
 fun cancel(t:Task){val pi=PendingIntent.getBroadcast(this,t.id,Intent(this,AlarmReceiver::class.java),PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE);if(pi!=null)getSystemService(AlarmManager::class.java).cancel(pi)}
 fun complete(t:Task){val a=TaskStore.tasks(this);a.find{it.id==t.id}?.done=true;TaskStore.persist(this,a);cancel(t);render();StatusNotifier.update(this)}
 fun deleteOne(t:Task){AlertDialog.Builder(this).setTitle("Xóa ${t.code}?").setMessage("CV sẽ bị xóa khỏi sổ công việc.").setNegativeButton("Hủy",null).setPositiveButton("Xóa"){_,_->val a=TaskStore.tasks(this);a.removeAll{it.id==t.id};TaskStore.persist(this,a);cancel(t);render();StatusNotifier.update(this)}.show()}
 fun deleteCompleted(){val n=TaskStore.tasks(this).count{it.done};if(n==0){Toast.makeText(this,"Không có CV hoàn thành để xóa",Toast.LENGTH_SHORT).show();return};AlertDialog.Builder(this).setTitle("Xóa $n CV đã hoàn thành?").setMessage("Các CV này sẽ bị xóa khỏi sổ công việc.").setNegativeButton("Hủy",null).setPositiveButton("Xóa tất cả"){_,_->TaskStore.persist(this,TaskStore.tasks(this).filter{!it.done});render();StatusNotifier.update(this)}.show()}
 fun render(){list.removeAllViews();homeList.removeAllViews();val f=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi"));val cnt=StatusNotifier.counts(this);val dpc=StatusNotifier.counts(this,"DPC");val gt=StatusNotifier.counts(this,"Gia Tân");val pending=cnt[0]+cnt[1]+cnt[2];status.text="Tổng chưa hoàn thành: $pending CV\nDPC ${dpc[0]+dpc[1]+dpc[2]} CV • GIA TÂN ${gt[0]+gt[1]+gt[2]} CV";status.setTextColor(if(cnt[0]>0)Color.rgb(190,20,20) else Color.DKGRAY);findViewById<TextView>(R.id.card_overdue).text="${cnt[0]}\nQuá hạn";findViewById<TextView>(R.id.card_today).text="${cnt[1]}\nHôm nay";findViewById<TextView>(R.id.card_upcoming).text="${cnt[2]}\nSắp tới";findViewById<TextView>(R.id.card_done).text="${cnt[3]}\nĐã hoàn thành";val total=pending+cnt[3];findViewById<ProgressBar>(R.id.progress).progress=if(total==0)0 else cnt[3]*100/total;findViewById<TextView>(R.id.update_time).text="Cập nhật: "+SimpleDateFormat("dd/MM HH:mm",Locale("vi")).format(Date());DailyWidget.updateAll(this);findViewById<TextView>(R.id.stats_text).text="TẤT CẢ\nQuá hạn: ${cnt[0]} • Hôm nay: ${cnt[1]} • Sắp tới: ${cnt[2]} • Hoàn thành: ${cnt[3]}\n\nDPC\nChưa hoàn thành: ${dpc[0]+dpc[1]+dpc[2]} • Hoàn thành: ${dpc[3]}\n\nGIA TÂN\nChưa hoàn thành: ${gt[0]+gt[1]+gt[2]} • Hoàn thành: ${gt[3]}"
  val all=TaskStore.tasks(this)
  all.filter{(filter=="ALL"||it.group==filter)&&(showDone.isChecked||!it.done)}.sortedWith(compareBy<Task>{it.done}.thenBy{it.whenMs}).forEach{t->
   val overdue=!t.done&&t.whenMs<System.currentTimeMillis(); val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(dp(14),dp(12),dp(14),dp(10))
   val bg=GradientDrawable(); bg.cornerRadius=dp(14).toFloat(); bg.setColor(if(overdue)Color.rgb(255,242,242) else Color.WHITE); bg.setStroke(dp(1),if(t.group=="Gia Tân")Color.rgb(204,232,213) else Color.rgb(213,226,241)); box.background=bg
   val lp=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT); lp.setMargins(0,dp(6),0,dp(6)); box.layoutParams=lp
   val tag=TextView(this); tag.text="${if(t.group=="Gia Tân")"GIA TÂN" else "DPC"}   •   ${t.code}"; tag.textSize=12f; tag.setTextColor(if(t.group=="Gia Tân")Color.rgb(36,138,75) else Color.rgb(13,95,166)); tag.setTypeface(null,android.graphics.Typeface.BOLD); box.addView(tag)
   val tv=TextView(this); tv.text="${t.title}${if(t.area.isBlank())"" else "\n${t.area}"}"; tv.textSize=16f; tv.setTextColor(Color.rgb(37,54,74)); tv.setTypeface(null,android.graphics.Typeface.BOLD); tv.setPadding(0,dp(5),0,dp(3)); box.addView(tv)
   if(t.note.isNotBlank()){val nt=TextView(this);nt.text="📝 Ghi chú: ${t.note}";nt.maxLines=2;nt.ellipsize=android.text.TextUtils.TruncateAt.END;nt.textSize=13f;nt.setTextColor(Color.rgb(71,85,105));nt.setPadding(0,dp(3),0,dp(4));box.addView(nt)}
   box.setOnClickListener{openTaskDetail(t.id)}
   val meta=TextView(this); meta.text="${if(overdue)"QUÁ HẠN • " else ""}Ưu tiên ${t.priority} • ${f.format(Date(t.whenMs))}${if(!t.done)" • ${remainingText(t.whenMs)}" else " • ✓ Hoàn thành"}"; meta.textSize=12f; meta.setTextColor(if(overdue)Color.rgb(180,35,35) else Color.rgb(100,116,139)); box.addView(meta)
   if(!t.done){val work=Button(this);work.text="▶ THỰC HIỆN CV";work.isAllCaps=false;work.textSize=12f;work.setOnClickListener{openWork(t.id)};box.addView(work)}
   val b=Button(this); b.text=if(t.done)"Xóa CV" else "✓ Hoàn thành nhanh"; b.isAllCaps=false; b.textSize=12f; b.setOnClickListener{if(t.done)deleteOne(t) else complete(t)}; box.addView(b); list.addView(box)
  }
  fun addHomeGroup(label:String,groupName:String,color:Int){
   val groupTasks=all.filter{!it.done&&it.group==groupName}.sortedBy{it.whenMs}; if(groupTasks.isEmpty()) return
   val head=TextView(this); head.text="$label  •  ${groupTasks.size} CV"; head.textSize=13f; head.setTextColor(color); head.setTypeface(null,android.graphics.Typeface.BOLD); head.setPadding(dp(2),dp(9),0,dp(3)); homeList.addView(head)
   groupTasks.take(3).forEach{t->
    val overdue=t.whenMs<System.currentTimeMillis(); val h=TextView(this); h.text="${t.code}  ·  ${t.title}${if(t.area.isBlank())"" else "\n${t.area}"}${if(t.note.isBlank())"" else "\n📝 ${t.note}"}\n${if(overdue)"Quá hạn" else remainingText(t.whenMs)} • Ưu tiên ${t.priority}"; h.maxLines=6; h.ellipsize=android.text.TextUtils.TruncateAt.END; h.textSize=14f; h.setTextColor(if(overdue)Color.rgb(180,35,35) else Color.rgb(37,54,74)); h.setPadding(dp(13),dp(10),dp(13),dp(10)); val hb=GradientDrawable(); hb.cornerRadius=dp(12).toFloat(); hb.setColor(if(overdue)Color.rgb(255,242,242) else Color.WHITE); hb.setStroke(dp(1),if(overdue)Color.rgb(245,190,190) else Color.rgb(225,232,240)); h.background=hb; val hlp=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT); hlp.setMargins(0,dp(3),0,dp(4)); h.layoutParams=hlp; h.setOnClickListener{openTaskDetail(t.id)}; homeList.addView(h)
   }
   if(groupTasks.size>3){val more=TextView(this); more.text="+ ${groupTasks.size-3} CV khác"; more.textSize=12f; more.setTextColor(color); more.setPadding(dp(8),dp(2),0,dp(4)); homeList.addView(more)}
  }
  addHomeGroup("DPC","DPC",Color.rgb(13,95,166)); addHomeGroup("GIA TÂN","Gia Tân",Color.rgb(36,138,75))
 }
 fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}
