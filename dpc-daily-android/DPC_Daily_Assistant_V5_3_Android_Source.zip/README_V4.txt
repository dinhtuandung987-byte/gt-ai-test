DPC Daily Assistant V4.0
- Nâng cấp từ source V3.8, giữ package com.giatan.dpcdaily để cập nhật trực tiếp và giữ dữ liệu cục bộ.
- Giao diện danh sách/home chuyển sang card bo góc, phân nhóm DPC và Gia Tân.
- Widget V4.0 bỏ 1 CV ưu tiên duy nhất; hiển thị riêng công việc DPC và GIA TÂN, tối đa 2 CV mỗi nhóm + số CV còn lại.
- Giữ logic mã CV, cảnh báo, trạng thái, lưu dữ liệu, widget và notification của V3.8.
