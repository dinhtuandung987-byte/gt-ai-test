DPC DAILY ASSISTANT V5.3

Nâng cấp từ V5.2.1:
- Hiển thị ghi chú ngắn ngay trên thẻ công việc Trang chủ và Danh sách.
- Chạm thẻ mở Chi tiết công việc đầy đủ.
- Chi tiết gồm ghi chú, khu vực, người phụ trách, thời hạn, ưu tiên, thông số, kết quả, số ảnh và trạng thái.
- Từ Chi tiết có thể vào THỰC HIỆN CV hoặc XEM BÁO CÁO.
- Giữ Technical Analysis, Auto Report, ảnh minh chứng, JSON Export/Restore.
- Giữ package com.giatan.dpcdaily và dữ liệu cũ.
- Version 5.3 / versionCode 15.
- Có GitHub Actions build APK.

Lưu ý backup ảnh: JSON hiện lưu URI ảnh, chưa nhúng file ảnh.
