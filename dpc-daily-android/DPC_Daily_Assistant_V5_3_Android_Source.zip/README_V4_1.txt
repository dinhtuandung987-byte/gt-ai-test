DPC Daily Assistant V4.1
- Nâng cấp từ V4.0, giữ package com.giatan.dpcdaily để cài đè và giữ dữ liệu.
- Mã CV mới tách theo nhóm: DPC-YYYY-#### và GT-YYYY-####.
- DPC và Gia Tân có bộ đếm STT riêng.
- CV cũ giữ nguyên mã để không phá lịch sử dữ liệu.
- Đổi nhóm trước khi lưu sẽ cập nhật mã dự kiến tương ứng.
- Không thay đổi GT System.
