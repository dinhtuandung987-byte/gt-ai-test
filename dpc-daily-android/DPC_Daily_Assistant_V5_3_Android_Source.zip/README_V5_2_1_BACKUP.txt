DPC Daily Assistant V5.2.1 - Backup & Restore

Nâng cấp từ V5.2 (Technical Analysis), không đổi package/dữ liệu cũ:
- Thêm mục "Sao lưu & khôi phục" trong Cài đặt.
- "XUẤT FILE SAO LƯU (JSON)": xuất toàn bộ công việc (mọi trường dữ liệu,
  kể cả tham chiếu ảnh minh chứng, thông số, kết quả, báo cáo đã tạo) ra
  1 file .json, người dùng chọn nơi lưu (Drive, bộ nhớ máy, gửi qua Zalo/
  email...). Ảnh không bị nhúng vào file (chỉ là tham chiếu URI đã cấp
  quyền đọc lâu dài) nên file sao lưu rất nhẹ.
- "KHÔI PHỤC TỪ FILE SAO LƯU": chọn lại file .json đã xuất trước đó.
  Có hộp xác nhận rõ ràng vì thao tác này GHI ĐÈ toàn bộ công việc hiện
  có trên máy, không thể hoàn tác.
- Sau khi khôi phục, toàn bộ báo thức của các công việc chưa hoàn thành
  và chưa tới hạn được ĐẶT LẠI tự động (không chỉ khôi phục dữ liệu im
  lặng) — nếu máy chưa bật quyền "Báo thức & lời nhắc" thì được nhắc bật
  lại ngay.
- Bộ đếm mã CV riêng theo nhóm (seq_dpc/seq_gt) cũng được khôi phục kèm
  theo, đảm bảo mã CV tạo tiếp theo không bị trùng với dữ liệu cũ.

Lưu ý sử dụng: nên xuất file sao lưu định kỳ (vd. cuối tuần) và lưu ở
một nơi khác ngoài điện thoại — vì toàn bộ dữ liệu app vẫn chỉ nằm cục
bộ trên máy, mất máy/xóa app/reset máy là mất dữ liệu nếu không có file
sao lưu gần nhất.
