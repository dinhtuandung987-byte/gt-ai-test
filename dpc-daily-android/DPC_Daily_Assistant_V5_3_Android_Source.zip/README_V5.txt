DPC Daily Assistant V5.0 - Field Execution
- Giữ package com.giatan.dpcdaily và dữ liệu SharedPreferences cũ.
- Thêm THỰC HIỆN CV từ Danh sách; chạm CV trên Trang chủ cũng mở thực hiện.
- Tự nhận dạng nhóm công việc và đưa checklist ảnh/thông số cần thu thập.
- Lưu Thông số/Ghi nhận, Kết quả xử lý và nhiều ảnh minh chứng theo từng mã CV.
- Cho phép Lưu tạm hoặc Hoàn thành ngay trong hồ sơ thực hiện.
- Tương thích dữ liệu V4.1: các trường mới dùng giá trị mặc định khi đọc dữ liệu cũ.
Lưu ý: V5.0 chưa gọi API AI; phần hướng dẫn hiện trường chạy offline để ổn định và không phụ thuộc mạng.
