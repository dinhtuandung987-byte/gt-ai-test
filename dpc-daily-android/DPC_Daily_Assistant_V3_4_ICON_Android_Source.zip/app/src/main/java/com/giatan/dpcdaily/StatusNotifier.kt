package com.giatan.dpcdaily

import android.app.*
import android.content.*
import android.os.Build
import java.util.*

object StatusNotifier {
    const val CHANNEL_STATUS="cv_status_v32"
    const val CHANNEL_ALERT="cv_alert_v32"
    const val STATUS_ID=32001

    fun createChannels(c:Context){ if(Build.VERSION.SDK_INT>=26){
        val nm=c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ALERT,"Cảnh báo DPC / Gia Tân",NotificationManager.IMPORTANCE_HIGH).apply{
            enableVibration(true); lockscreenVisibility=Notification.VISIBILITY_PUBLIC; setShowBadge(true)
        })
        nm.createNotificationChannel(NotificationChannel(CHANNEL_STATUS,"Tổng quan DPC / Gia Tân",NotificationManager.IMPORTANCE_DEFAULT).apply{setShowBadge(true);lockscreenVisibility=Notification.VISIBILITY_PUBLIC})
    }}

    fun counts(c:Context, group:String?=null):IntArray{
        val now=System.currentTimeMillis(); val cal=Calendar.getInstance(); cal.timeInMillis=now
        val y=cal.get(Calendar.YEAR); val d=cal.get(Calendar.DAY_OF_YEAR)
        var overdue=0;var today=0;var upcoming=0;var done=0
        TaskStore.tasks(c).filter{group==null || it.group==group}.forEach{t-> if(t.done) done++ else if(t.whenMs<now) overdue++ else {
            val x=Calendar.getInstance();x.timeInMillis=t.whenMs
            if(x.get(Calendar.YEAR)==y && x.get(Calendar.DAY_OF_YEAR)==d) today++ else upcoming++
        }}
        return intArrayOf(overdue,today,upcoming,done)
    }

    fun update(c:Context){
        createChannels(c)
        val a=TaskStore.tasks(c); val cnt=counts(c); val pending=cnt[0]+cnt[1]+cnt[2]
        val dpc=counts(c,"DPC"); val gt=counts(c,"Gia Tân")
        val dpcPending=dpc[0]+dpc[1]+dpc[2]; val gtPending=gt[0]+gt[1]+gt[2]
        val priority=a.filter{!it.done}.sortedBy{it.whenMs}.firstOrNull()
        val open=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val title=if(cnt[0]>0) "⚠ QUÁ HẠN ${cnt[0]} CV • DPC $dpcPending • GT $gtPending" else "DPC DAILY • Còn $pending CV • DPC $dpcPending • GT $gtPending"
        val line="Quá hạn ${cnt[0]} | Hôm nay ${cnt[1]} | Sắp tới ${cnt[2]} | Xong ${cnt[3]}"
        val detail=if(priority!=null) "Ưu tiên: ${priority.group} • ${priority.code} – ${priority.title}${if(priority.area.isBlank())"" else " • ${priority.area}"}" else "Không còn công việc đang chờ xử lý"
        val n=Notification.Builder(c,CHANNEL_STATUS)
            .setSmallIcon(android.R.drawable.ic_menu_agenda).setContentTitle(title).setContentText(line)
            .setStyle(Notification.BigTextStyle().bigText("$line\n$detail"))
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).setNumber(pending).setVisibility(Notification.VISIBILITY_PUBLIC).build()
        c.getSystemService(NotificationManager::class.java).notify(STATUS_ID,n)
        DailyWidget.updateAll(c)
    }
}
