package com.giatan.dpcdaily
import android.app.*
import android.content.*
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){
    if(i.action!=Intent.ACTION_BOOT_COMPLETED)return
    val am=c.getSystemService(AlarmManager::class.java); val now=System.currentTimeMillis()
    TaskStore.tasks(c).filter{!it.done && it.whenMs>now}.forEach{t->
        val x=Intent(c,AlarmReceiver::class.java).putExtra("code",t.code).putExtra("title",t.title).putExtra("group",t.group).putExtra("area",t.area)
        val pi=PendingIntent.getBroadcast(c,t.id,x,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try{ if(android.os.Build.VERSION.SDK_INT<31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.whenMs,pi) }catch(_:Exception){}
    }
    StatusNotifier.update(c)
}}
