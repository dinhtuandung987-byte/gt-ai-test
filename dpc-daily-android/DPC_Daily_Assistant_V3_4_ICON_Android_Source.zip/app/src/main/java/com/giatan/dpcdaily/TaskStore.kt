package com.giatan.dpcdaily

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Task(val id:Int,val code:String,val group:String,val title:String,val area:String,val owner:String,val note:String,val whenMs:Long,var done:Boolean=false)

object TaskStore {
    fun prefs(c:Context)=c.getSharedPreferences("dpc_daily",Context.MODE_PRIVATE)
    fun tasks(c:Context):MutableList<Task>{
        val a=mutableListOf<Task>()
        try{
            val j=JSONArray(prefs(c).getString("tasks","[]"))
            for(i in 0 until j.length()){
                val o=j.getJSONObject(i)
                a.add(Task(o.getInt("id"),o.getString("code"),o.optString("group","DPC"),o.getString("title"),o.optString("area"),o.optString("owner"),o.optString("note"),o.getLong("when"),o.optBoolean("done")))
            }
        }catch(_:Exception){}
        return a
    }
    fun persist(c:Context,a:List<Task>){
        val j=JSONArray()
        a.forEach{t->j.put(JSONObject().put("id",t.id).put("code",t.code).put("group",t.group).put("title",t.title).put("area",t.area).put("owner",t.owner).put("note",t.note).put("when",t.whenMs).put("done",t.done))}
        prefs(c).edit().putString("tasks",j.toString()).apply()
    }
}
