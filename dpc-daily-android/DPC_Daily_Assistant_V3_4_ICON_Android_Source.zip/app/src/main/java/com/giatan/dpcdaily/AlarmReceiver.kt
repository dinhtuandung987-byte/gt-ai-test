package com.giatan.dpcdaily
import android.app.*
import android.content.*
class AlarmReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){
    StatusNotifier.createChannels(c)
    val code=i.getStringExtra("code")?:"CV";val title=i.getStringExtra("title")?:"Công việc đến hạn";val group=i.getStringExtra("group")?:"DPC";val area=i.getStringExtra("area")?:""
    val open=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val brand=if(group=="Gia Tân") "GIA TÂN" else "DPC"
    val text="$code • $title${if(area.isBlank())"" else " • $area"}"
    val n=Notification.Builder(c,StatusNotifier.CHANNEL_ALERT).setSmallIcon(android.R.drawable.ic_dialog_alert)
        .setContentTitle("⚠ $brand – ĐẾN HẠN / QUÁ HẠN").setContentText(text)
        .setStyle(Notification.BigTextStyle().bigText("$text\nNhóm: $group"))
        .setContentIntent(open).setAutoCancel(true).setPriority(Notification.PRIORITY_MAX)
        .setCategory(Notification.CATEGORY_ALARM).setVisibility(Notification.VISIBILITY_PUBLIC).setDefaults(Notification.DEFAULT_ALL).build()
    c.getSystemService(NotificationManager::class.java).notify(code.hashCode(),n);StatusNotifier.update(c)
}}
