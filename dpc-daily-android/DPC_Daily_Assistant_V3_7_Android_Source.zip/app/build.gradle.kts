plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace="com.giatan.dpcdaily"; compileSdk=35
 defaultConfig { applicationId="com.giatan.dpcdaily"; minSdk=26; targetSdk=35; versionCode=7; versionName="3.7" }
 compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget="17" }
}
