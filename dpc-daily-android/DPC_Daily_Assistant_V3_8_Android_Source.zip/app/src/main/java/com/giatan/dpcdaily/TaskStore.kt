package com.giatan.dpcdaily

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Task(val id:Int,val code:String,val group:String,val title:String,val area:String,val owner:String,val note:String,val whenMs:Long,var done:Boolean=false,val priority:String="Trung bình")

object TaskStore {
    fun prefs(c:Context)=c.getSharedPreferences("dpc_daily",Context.MODE_PRIVATE)
    fun tasks(c:Context):MutableList<Task>{
        val a=mutableListOf<Task>()
        try{
            val j=JSONArray(prefs(c).getString("tasks","[]"))
            for(i in 0 until j.length()){
                val o=j.getJSONObject(i)
                a.add(Task(o.getInt("id"),o.getString("code"),o.optString("group","DPC"),o.getString("title"),o.optString("area"),o.optString("owner"),o.optString("note"),o.getLong("when"),o.optBoolean("done"),o.optString("priority","Trung bình")))
            }
        }catch(_:Exception){}
        return a
    }
    fun safeSeq(c:Context):Int{
        val saved=prefs(c).getInt("seq",0)
        val maxTask=tasks(c).mapNotNull{it.code.substringAfterLast("-").toIntOrNull()}.maxOrNull()?:0
        val n=kotlin.math.max(saved,maxTask)
        if(n!=saved)prefs(c).edit().putInt("seq",n).apply()
        return n
    }

    fun persist(c:Context,a:List<Task>){
        val j=JSONArray()
        a.forEach{t->j.put(JSONObject().put("id",t.id).put("code",t.code).put("group",t.group).put("title",t.title).put("area",t.area).put("owner",t.owner).put("note",t.note).put("when",t.whenMs).put("done",t.done).put("priority",t.priority))}
        prefs(c).edit().putString("tasks",j.toString()).apply()
    }
}
