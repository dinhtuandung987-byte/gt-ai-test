package com.giatan.dpcdaily

import android.app.*
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.graphics.Color
import android.widget.RemoteViews
import java.util.concurrent.TimeUnit
import java.text.SimpleDateFormat
import java.util.*

class DailyWidget:AppWidgetProvider(){
    override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){ ids.forEach{update(c,m,it)} }
    override fun onEnabled(c:Context){ StatusNotifier.update(c) }
    companion object{
        fun updateAll(c:Context){val m=AppWidgetManager.getInstance(c);m.getAppWidgetIds(ComponentName(c,DailyWidget::class.java)).forEach{update(c,m,it)}}
        private fun update(c:Context,m:AppWidgetManager,id:Int){
            val cnt=StatusNotifier.counts(c); val pending=cnt[0]+cnt[1]+cnt[2]
            val dpc=StatusNotifier.counts(c,"DPC");val gt=StatusNotifier.counts(c,"Gia Tân")
            val p=TaskStore.tasks(c).filter{!it.done}.sortedBy{it.whenMs}.firstOrNull()
            val v=RemoteViews(c.packageName,R.layout.widget_daily)
            v.setTextViewText(R.id.w_overdue,"${cnt[0]}\nQuá hạn");v.setTextViewText(R.id.w_today,"${cnt[1]}\nHôm nay");v.setTextViewText(R.id.w_upcoming,"${cnt[2]}\nSắp tới");v.setTextViewText(R.id.w_done,"${cnt[3]}\nĐã hoàn thành")
            v.setTextViewText(R.id.w_total,"Tổng chưa hoàn thành: $pending CV")
            v.setTextViewText(R.id.w_groups,"DPC ${dpc[0]+dpc[1]+dpc[2]} CV   •   GIA TÂN ${gt[0]+gt[1]+gt[2]} CV")
            val total=pending+cnt[3];val progress=if(total==0)0 else cnt[3]*100/total;v.setProgressBar(R.id.w_progress,100,progress,false);v.setTextViewText(R.id.w_progress_text,"Tiến độ: $progress%");v.setTextViewText(R.id.w_updated,"Cập nhật: "+SimpleDateFormat("HH:mm",Locale("vi")).format(Date()))
            if(p==null)v.setTextViewText(R.id.w_priority,"✓ Không còn CV đang chờ") else {
                val late=System.currentTimeMillis()-p.whenMs;val lateText=if(late>0)" • Quá hạn ${TimeUnit.MILLISECONDS.toHours(late)} giờ ${TimeUnit.MILLISECONDS.toMinutes(late)%60} phút" else ""
                v.setTextViewText(R.id.w_priority,"Ưu tiên: ${p.code} – ${p.title}\n${p.group}${if(p.area.isBlank())"" else " • ${p.area}"}$lateText")
            }
            v.setTextColor(R.id.w_priority,if(cnt[0]>0)Color.rgb(190,25,25) else Color.rgb(30,30,30))
            val pi=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);v.setOnClickPendingIntent(R.id.widget_root,pi);m.updateAppWidget(id,v)
        }
    }
}
