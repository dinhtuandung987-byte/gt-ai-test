package com.giatan.dpcdaily
import android.app.*
import android.content.*
class AlarmReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){
    StatusNotifier.createChannels(c)
    val code=i.getStringExtra("code")?:"CV";val title=i.getStringExtra("title")?:"Công việc đến hạn";val group=i.getStringExtra("group")?:"DPC";val area=i.getStringExtra("area")?:""
    val open=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val text="$group${if(area.isBlank())"" else " • $area"}"
    val n=Notification.Builder(c,StatusNotifier.CHANNEL_ALERT).setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("ĐẾN HẠN • $code").setContentText(title).setStyle(Notification.BigTextStyle().bigText("$title\n$text")).setContentIntent(open).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH).build()
    c.getSystemService(NotificationManager::class.java).notify(code.hashCode(),n);StatusNotifier.update(c)
}}
