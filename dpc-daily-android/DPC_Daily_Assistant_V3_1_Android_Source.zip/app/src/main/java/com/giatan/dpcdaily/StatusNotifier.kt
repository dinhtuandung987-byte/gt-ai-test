package com.giatan.dpcdaily

import android.app.*
import android.content.*
import android.os.Build
import java.text.SimpleDateFormat
import java.util.*

object StatusNotifier {
    const val CHANNEL_STATUS="cv_status"
    const val CHANNEL_ALERT="cv_alert"
    const val STATUS_ID=31001

    fun createChannels(c:Context){ if(Build.VERSION.SDK_INT>=26){
        val nm=c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ALERT,"Cảnh báo CV đến hạn",NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CHANNEL_STATUS,"Tổng quan công việc",NotificationManager.IMPORTANCE_DEFAULT).apply{setShowBadge(true)})
    }}

    fun counts(c:Context):IntArray{
        val now=System.currentTimeMillis(); val cal=Calendar.getInstance(); cal.timeInMillis=now
        val y=cal.get(Calendar.YEAR); val d=cal.get(Calendar.DAY_OF_YEAR)
        var overdue=0;var today=0;var upcoming=0;var done=0
        TaskStore.tasks(c).forEach{t-> if(t.done) done++ else if(t.whenMs<now) overdue++ else {
            val x=Calendar.getInstance();x.timeInMillis=t.whenMs
            if(x.get(Calendar.YEAR)==y && x.get(Calendar.DAY_OF_YEAR)==d) today++ else upcoming++
        }}
        return intArrayOf(overdue,today,upcoming,done)
    }

    fun update(c:Context){
        createChannels(c)
        val a=TaskStore.tasks(c); val cnt=counts(c); val pending=cnt[0]+cnt[1]+cnt[2]
        val priority=a.filter{!it.done}.sortedBy{it.whenMs}.firstOrNull()
        val open=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val line="Quá hạn: ${cnt[0]} | Hôm nay: ${cnt[1]} | Sắp tới: ${cnt[2]}"
        val detail=if(priority!=null) "Ưu tiên: ${priority.code} – ${priority.title}\n${priority.group}${if(priority.area.isBlank())"" else " • ${priority.area}"}" else "Không còn công việc đang chờ xử lý"
        val n=Notification.Builder(c,CHANNEL_STATUS)
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setContentTitle("DPC DAILY • Còn $pending CV chưa hoàn thành")
            .setContentText(line)
            .setStyle(Notification.BigTextStyle().bigText("$line\n$detail"))
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).setNumber(pending).build()
        c.getSystemService(NotificationManager::class.java).notify(STATUS_ID,n)
        DailyWidget.updateAll(c)
    }
}
