package com.giatan.dpcdaily

import android.app.*
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.widget.RemoteViews

class DailyWidget:AppWidgetProvider(){
    override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){ ids.forEach{update(c,m,it)} }
    override fun onEnabled(c:Context){ StatusNotifier.update(c) }
    companion object{
        fun updateAll(c:Context){
            val m=AppWidgetManager.getInstance(c); val ids=m.getAppWidgetIds(ComponentName(c,DailyWidget::class.java)); ids.forEach{update(c,m,it)}
        }
        private fun update(c:Context,m:AppWidgetManager,id:Int){
            val cnt=StatusNotifier.counts(c); val pending=cnt[0]+cnt[1]+cnt[2]
            val p=TaskStore.tasks(c).filter{!it.done}.sortedBy{it.whenMs}.firstOrNull()
            val v=RemoteViews(c.packageName,R.layout.widget_daily)
            v.setTextViewText(R.id.w_total,"Còn $pending CV chưa hoàn thành")
            v.setTextViewText(R.id.w_counts,"Quá hạn ${cnt[0]}   •   Hôm nay ${cnt[1]}   •   Sắp tới ${cnt[2]}   •   Xong ${cnt[3]}")
            v.setTextViewText(R.id.w_priority,if(p==null)"✓ Không còn CV đang chờ" else "Ưu tiên: ${p.code} – ${p.title}\n${p.group}${if(p.area.isBlank())"" else " • ${p.area}"}")
            val pi=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.widget_root,pi);m.updateAppWidget(id,v)
        }
    }
}
