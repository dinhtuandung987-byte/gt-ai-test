package com.giatan.dpcdaily
import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity:Activity(){
 lateinit var code:EditText;lateinit var title:EditText;lateinit var area:EditText;lateinit var owner:EditText;lateinit var note:EditText;lateinit var pick:Button;lateinit var list:LinearLayout;lateinit var status:TextView;lateinit var group:Spinner;lateinit var showDone:CheckBox
 var whenMs=0L;var filter="ALL";val prefs by lazy{TaskStore.prefs(this)}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  code=findViewById(R.id.code);title=findViewById(R.id.title);area=findViewById(R.id.area);owner=findViewById(R.id.owner);note=findViewById(R.id.note);pick=findViewById(R.id.pick);list=findViewById(R.id.list);status=findViewById(R.id.status);group=findViewById(R.id.group);showDone=findViewById(R.id.show_done)
  group.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("DPC","Gia Tân"));StatusNotifier.createChannels(this);requestNotify();newCode();render();StatusNotifier.update(this)
  pick.setOnClickListener{chooseDate()};findViewById<Button>(R.id.save).setOnClickListener{saveTask()};showDone.setOnCheckedChangeListener{_,_->render()}
  findViewById<Button>(R.id.filter_all).setOnClickListener{filter="ALL";render()};findViewById<Button>(R.id.filter_dpc).setOnClickListener{filter="DPC";render()};findViewById<Button>(R.id.filter_gt).setOnClickListener{filter="Gia Tân";render()};findViewById<Button>(R.id.delete_done).setOnClickListener{deleteCompleted()}
 }
 override fun onResume(){super.onResume();render();StatusNotifier.update(this)}
 fun requestNotify(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),100)}
 fun newCode(){val n=prefs.getInt("seq",0)+1;code.setText("CV-${Calendar.getInstance().get(Calendar.YEAR)}-${"%04d".format(n)}")}
 fun chooseDate(){val c=Calendar.getInstance();DatePickerDialog(this,{_,y,m,d->TimePickerDialog(this,{_,h,min->c.set(y,m,d,h,min,0);whenMs=c.timeInMillis;pick.text=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi")).format(c.time)},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show()},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()}
 fun saveTask(){if(title.text.toString().trim().isEmpty()){Toast.makeText(this,"Nhập tên công việc",Toast.LENGTH_SHORT).show();return};if(whenMs==0L){Toast.makeText(this,"Chọn ngày giờ cảnh báo",Toast.LENGTH_SHORT).show();return};val seq=prefs.getInt("seq",0)+1;val c="CV-${Calendar.getInstance().get(Calendar.YEAR)}-${"%04d".format(seq)}";val id=(System.currentTimeMillis()%Int.MAX_VALUE).toInt();val a=TaskStore.tasks(this);val t=Task(id,c,group.selectedItem.toString(),title.text.toString().trim(),area.text.toString().trim(),owner.text.toString().trim(),note.text.toString().trim(),whenMs);a.add(0,t);TaskStore.persist(this,a);prefs.edit().putInt("seq",seq).apply();schedule(t);Toast.makeText(this,"Đã lưu $c",Toast.LENGTH_LONG).show();title.setText("");area.setText("");owner.setText("");note.setText("");whenMs=0;pick.text="Chọn ngày giờ";newCode();render();StatusNotifier.update(this)}
 fun schedule(t:Task){val am=getSystemService(AlarmManager::class.java);if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));Toast.makeText(this,"Hãy bật quyền Báo thức & lời nhắc.",Toast.LENGTH_LONG).show();return};val i=Intent(this,AlarmReceiver::class.java).putExtra("code",t.code).putExtra("title",t.title).putExtra("group",t.group).putExtra("area",t.area);val pi=PendingIntent.getBroadcast(this,t.id,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.whenMs,pi)}
 fun cancel(t:Task){val pi=PendingIntent.getBroadcast(this,t.id,Intent(this,AlarmReceiver::class.java),PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE);if(pi!=null)getSystemService(AlarmManager::class.java).cancel(pi)}
 fun complete(t:Task){val a=TaskStore.tasks(this);a.find{it.id==t.id}?.done=true;TaskStore.persist(this,a);cancel(t);render();StatusNotifier.update(this)}
 fun deleteOne(t:Task){AlertDialog.Builder(this).setTitle("Xóa ${t.code}?").setMessage("CV sẽ bị xóa khỏi sổ công việc.").setNegativeButton("Hủy",null).setPositiveButton("Xóa"){_,_->val a=TaskStore.tasks(this);a.removeAll{it.id==t.id};TaskStore.persist(this,a);cancel(t);render();StatusNotifier.update(this)}.show()}
 fun deleteCompleted(){val n=TaskStore.tasks(this).count{it.done};if(n==0){Toast.makeText(this,"Không có CV hoàn thành để xóa",Toast.LENGTH_SHORT).show();return};AlertDialog.Builder(this).setTitle("Xóa $n CV đã hoàn thành?").setMessage("Các CV này sẽ bị xóa khỏi sổ công việc.").setNegativeButton("Hủy",null).setPositiveButton("Xóa tất cả"){_,_->TaskStore.persist(this,TaskStore.tasks(this).filter{!it.done});render();StatusNotifier.update(this)}.show()}
 fun render(){list.removeAllViews();val f=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi"));val cnt=StatusNotifier.counts(this);val dpc=StatusNotifier.counts(this,"DPC");val gt=StatusNotifier.counts(this,"Gia Tân");val pending=cnt[0]+cnt[1]+cnt[2];status.text="CHƯA HOÀN THÀNH: $pending CV • Quá hạn ${cnt[0]} • Hôm nay ${cnt[1]} • Sắp tới ${cnt[2]} • Xong ${cnt[3]}\nDPC ${dpc[0]+dpc[1]+dpc[2]} CV • GIA TÂN ${gt[0]+gt[1]+gt[2]} CV • Bộ lọc: ${if(filter=="ALL")"TẤT CẢ" else filter}";status.setTextColor(if(cnt[0]>0)Color.rgb(190,20,20) else Color.DKGRAY)
  TaskStore.tasks(this).filter{(filter=="ALL"||it.group==filter)&&(showDone.isChecked||!it.done)}.sortedWith(compareBy<Task>{it.done}.thenBy{it.whenMs}).forEach{t->val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(12,12,12,18);val tv=TextView(this);val overdue=!t.done&&t.whenMs<System.currentTimeMillis();tv.text="${if(overdue)"🔴 QUÁ HẠN • " else ""}[${if(t.group=="Gia Tân")"GIA TÂN" else "DPC"}] ${t.code} — ${t.title}\n${if(t.area.isBlank())"" else "${t.area} • "}${f.format(Date(t.whenMs))}${if(t.done)" • ✓ HOÀN THÀNH" else ""}";tv.textSize=16f;if(overdue){tv.setTextColor(Color.rgb(190,20,20));tv.setBackgroundColor(Color.rgb(255,225,225));tv.setPadding(16,16,16,16)};box.addView(tv);if(!t.done){val b=Button(this);b.text="HOÀN THÀNH";b.setOnClickListener{complete(t)};box.addView(b)}else{val del=Button(this);del.text="XÓA CV";del.setOnClickListener{deleteOne(t)};box.addView(del)};list.addView(box)}
 }
}
