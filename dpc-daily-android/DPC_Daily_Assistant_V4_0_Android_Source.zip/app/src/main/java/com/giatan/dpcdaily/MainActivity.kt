package com.giatan.dpcdaily
import android.Manifest
import android.app.*
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.widget.*
import android.graphics.Rect
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import java.text.SimpleDateFormat
import java.util.*

class MainActivity:Activity(){
 lateinit var code:EditText;lateinit var title:EditText;lateinit var area:EditText;lateinit var owner:EditText;lateinit var note:EditText;lateinit var pick:Button;lateinit var list:LinearLayout;lateinit var homeList:LinearLayout;lateinit var status:TextView;lateinit var group:Spinner;lateinit var showDone:CheckBox; var selectedGroup="DPC"
 var whenMs=0L;var filter="ALL";var selectedPriority="Trung bình";val prefs by lazy{TaskStore.prefs(this)}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  code=findViewById(R.id.code);title=findViewById(R.id.title);area=findViewById(R.id.area);owner=findViewById(R.id.owner);note=findViewById(R.id.note);pick=findViewById(R.id.pick);list=findViewById(R.id.list);status=findViewById(R.id.status);group=findViewById(R.id.group);showDone=findViewById(R.id.show_done)
  group.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("DPC","Gia Tân"));homeList=findViewById(R.id.home_list);StatusNotifier.createChannels(this);requestNotify();newCode();setupNavigation();selectGroup("DPC");render();StatusNotifier.update(this)
  setupKeyboardSafeUi();pick.setOnClickListener{chooseDate()};findViewById<Button>(R.id.save).setOnClickListener{saveTask()};showDone.setOnCheckedChangeListener{_,_->render()}
  findViewById<Button>(R.id.filter_all).setOnClickListener{filter="ALL";render()};findViewById<Button>(R.id.filter_dpc).setOnClickListener{filter="DPC";render()};findViewById<Button>(R.id.filter_gt).setOnClickListener{filter="Gia Tân";render()};findViewById<Button>(R.id.group_dpc).setOnClickListener{selectGroup("DPC")};findViewById<Button>(R.id.group_gt).setOnClickListener{selectGroup("Gia Tân")};findViewById<Button>(R.id.priority_high).setOnClickListener{selectPriority("Cao")};findViewById<Button>(R.id.priority_medium).setOnClickListener{selectPriority("Trung bình")};findViewById<Button>(R.id.priority_low).setOnClickListener{selectPriority("Thấp")};selectPriority("Trung bình");findViewById<Button>(R.id.delete_done).setOnClickListener{deleteCompleted()};findViewById<Button>(R.id.add_widget).setOnClickListener{requestHomeWidget()};offerWidgetOnce()
 }
 override fun onResume(){super.onResume();render();StatusNotifier.update(this)}

 fun requestHomeWidget(){
  val awm=AppWidgetManager.getInstance(this)
  val provider=ComponentName(this,DailyWidget::class.java)
  if(Build.VERSION.SDK_INT>=26 && awm.isRequestPinAppWidgetSupported){
   val ok=awm.requestPinAppWidget(provider,null,null)
   if(!ok) Toast.makeText(this,"Mở mục Widget của màn hình chính và chọn DPC Daily Assistant.",Toast.LENGTH_LONG).show()
  }else Toast.makeText(this,"Nhấn giữ màn hình chính → Widget → DPC Daily Assistant.",Toast.LENGTH_LONG).show()
 }
 fun offerWidgetOnce(){
  val key="widget_offer_v38"
  if(!prefs.getBoolean(key,false)){
   prefs.edit().putBoolean(key,true).apply()
   AlertDialog.Builder(this).setTitle("Đưa DPC Daily ra màn hình chính")
    .setMessage("V3.8 có bảng Widget lớn đúng mẫu: 4 trạng thái, tổng CV, tiến độ và công việc ưu tiên. Android cần anh xác nhận một lần để đặt Widget lên màn hình chính.")
    .setNegativeButton("Để sau",null).setPositiveButton("THÊM WIDGET"){_,_->requestHomeWidget()}.show()
  }
 }

 fun setupKeyboardSafeUi(){
  window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
  val root=findViewById<View>(R.id.root_layout);val nav=findViewById<View>(R.id.bottom_nav);val create=findViewById<ScrollView>(R.id.page_create)
  if(Build.VERSION.SDK_INT>=23){
   root.setOnApplyWindowInsetsListener{_,ins->
    val bottom=if(Build.VERSION.SDK_INT>=30) ins.getInsets(WindowInsets.Type.navigationBars()).bottom else ins.systemWindowInsetBottom
    nav.setPadding(nav.paddingLeft,nav.paddingTop,nav.paddingRight,bottom+6)
    nav.layoutParams.height=resources.displayMetrics.density.times(58).toInt()+bottom
    ins
   }
  }
  fun reveal(v:View){ create.postDelayed({
    val r=Rect();v.getDrawingRect(r);create.offsetDescendantRectToMyCoords(v,r);r.bottom+=resources.displayMetrics.density.times(160).toInt();create.requestChildRectangleOnScreen(v,r,true)
   },180) }
  root.viewTreeObserver.addOnGlobalLayoutListener{
   val r=Rect();root.getWindowVisibleDisplayFrame(r);val keyboard=root.rootView.height-r.bottom;val open=keyboard>root.rootView.height*0.15
   nav.visibility=if(open) View.GONE else View.VISIBLE
   if(open) currentFocus?.let{reveal(it)}
  }
  listOf(title,area,owner,note).forEach{v->v.setOnFocusChangeListener{view,has->if(has)reveal(view)}}
 }
 fun setupNavigation(){
  val pages=listOf(findViewById<android.view.View>(R.id.page_home),findViewById(R.id.page_create),findViewById(R.id.page_list),findViewById(R.id.page_stats),findViewById(R.id.page_settings))
  fun show(i:Int){pages.forEachIndexed{n,v->v.visibility=if(n==i)android.view.View.VISIBLE else android.view.View.GONE};render()}
  findViewById<Button>(R.id.nav_home).setOnClickListener{show(0)};findViewById<Button>(R.id.nav_create).setOnClickListener{show(1)};findViewById<Button>(R.id.nav_list).setOnClickListener{show(2)};findViewById<Button>(R.id.nav_stats).setOnClickListener{show(3)};findViewById<Button>(R.id.nav_settings).setOnClickListener{show(4)}
 }
 fun selectGroup(g:String){selectedGroup=g;group.setSelection(if(g=="DPC")0 else 1);val d=findViewById<Button>(R.id.group_dpc);val gt=findViewById<Button>(R.id.group_gt);val hint=findViewById<TextView>(R.id.group_hint);if(g=="DPC"){d.setBackgroundColor(Color.rgb(10,116,230));d.setTextColor(Color.WHITE);gt.setBackgroundColor(Color.rgb(235,238,242));gt.setTextColor(Color.DKGRAY);hint.text="DPC • An toàn • Ổn định • Hiệu quả";hint.setTextColor(Color.rgb(11,95,158))}else{gt.setBackgroundColor(Color.rgb(36,145,72));gt.setTextColor(Color.WHITE);d.setBackgroundColor(Color.rgb(235,238,242));d.setTextColor(Color.DKGRAY);hint.text="GIA TÂN • Điện nước • Máy móc • Dịch vụ tận tâm";hint.setTextColor(Color.rgb(36,125,62))}}

 fun selectPriority(p:String){selectedPriority=p;val hi=findViewById<Button>(R.id.priority_high);val med=findViewById<Button>(R.id.priority_medium);val low=findViewById<Button>(R.id.priority_low);listOf(hi,med,low).forEach{it.setTextColor(Color.DKGRAY);it.setBackgroundColor(Color.rgb(235,238,242))};when(p){"Cao"->{hi.setBackgroundColor(Color.rgb(210,40,40));hi.setTextColor(Color.WHITE)};"Thấp"->{low.setBackgroundColor(Color.rgb(36,145,72));low.setTextColor(Color.WHITE)};else->{med.setBackgroundColor(Color.rgb(238,145,25));med.setTextColor(Color.WHITE)}}}
 fun remainingText(ms:Long):String{val d=ms-System.currentTimeMillis();val a=kotlin.math.abs(d);val days=a/86400000;val hours=(a%86400000)/3600000;val mins=(a%3600000)/60000;val txt=if(days>0)"${days} ngày ${hours}h" else if(hours>0)"${hours}h ${mins}′" else "${mins} phút";return if(d<0)"Quá hạn $txt" else "Còn $txt"}
 fun requestNotify(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),100)}
 fun newCode(){val n=TaskStore.safeSeq(this)+1;code.setText("CV-${Calendar.getInstance().get(Calendar.YEAR)}-${"%04d".format(n)}")}
 fun chooseDate(){val c=Calendar.getInstance();DatePickerDialog(this,{_,y,m,d->TimePickerDialog(this,{_,h,min->c.set(y,m,d,h,min,0);whenMs=c.timeInMillis;pick.text=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi")).format(c.time)},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show()},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()}
 fun saveTask(){if(title.text.toString().trim().isEmpty()){Toast.makeText(this,"Nhập tên công việc",Toast.LENGTH_SHORT).show();return};if(whenMs==0L){Toast.makeText(this,"Chọn ngày giờ cảnh báo",Toast.LENGTH_SHORT).show();return};val seq=TaskStore.safeSeq(this)+1;val c="CV-${Calendar.getInstance().get(Calendar.YEAR)}-${"%04d".format(seq)}";val id=(System.currentTimeMillis()%Int.MAX_VALUE).toInt();val a=TaskStore.tasks(this);val t=Task(id,c,selectedGroup,title.text.toString().trim(),area.text.toString().trim(),owner.text.toString().trim(),note.text.toString().trim(),whenMs,false,selectedPriority);a.add(0,t);TaskStore.persist(this,a);prefs.edit().putInt("seq",seq).apply();schedule(t);Toast.makeText(this,"Đã lưu $c",Toast.LENGTH_LONG).show();title.setText("");area.setText("");owner.setText("");note.setText("");whenMs=0;pick.text="Chọn ngày giờ";selectPriority("Trung bình");newCode();render();StatusNotifier.update(this)}
 fun schedule(t:Task){val am=getSystemService(AlarmManager::class.java);if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));Toast.makeText(this,"Hãy bật quyền Báo thức & lời nhắc.",Toast.LENGTH_LONG).show();return};val i=Intent(this,AlarmReceiver::class.java).putExtra("code",t.code).putExtra("title",t.title).putExtra("group",t.group).putExtra("area",t.area);val pi=PendingIntent.getBroadcast(this,t.id,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.whenMs,pi)}
 fun cancel(t:Task){val pi=PendingIntent.getBroadcast(this,t.id,Intent(this,AlarmReceiver::class.java),PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE);if(pi!=null)getSystemService(AlarmManager::class.java).cancel(pi)}
 fun complete(t:Task){val a=TaskStore.tasks(this);a.find{it.id==t.id}?.done=true;TaskStore.persist(this,a);cancel(t);render();StatusNotifier.update(this)}
 fun deleteOne(t:Task){AlertDialog.Builder(this).setTitle("Xóa ${t.code}?").setMessage("CV sẽ bị xóa khỏi sổ công việc.").setNegativeButton("Hủy",null).setPositiveButton("Xóa"){_,_->val a=TaskStore.tasks(this);a.removeAll{it.id==t.id};TaskStore.persist(this,a);cancel(t);render();StatusNotifier.update(this)}.show()}
 fun deleteCompleted(){val n=TaskStore.tasks(this).count{it.done};if(n==0){Toast.makeText(this,"Không có CV hoàn thành để xóa",Toast.LENGTH_SHORT).show();return};AlertDialog.Builder(this).setTitle("Xóa $n CV đã hoàn thành?").setMessage("Các CV này sẽ bị xóa khỏi sổ công việc.").setNegativeButton("Hủy",null).setPositiveButton("Xóa tất cả"){_,_->TaskStore.persist(this,TaskStore.tasks(this).filter{!it.done});render();StatusNotifier.update(this)}.show()}
 fun render(){list.removeAllViews();homeList.removeAllViews();val f=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("vi"));val cnt=StatusNotifier.counts(this);val dpc=StatusNotifier.counts(this,"DPC");val gt=StatusNotifier.counts(this,"Gia Tân");val pending=cnt[0]+cnt[1]+cnt[2];status.text="Tổng chưa hoàn thành: $pending CV\nDPC ${dpc[0]+dpc[1]+dpc[2]} CV • GIA TÂN ${gt[0]+gt[1]+gt[2]} CV";status.setTextColor(if(cnt[0]>0)Color.rgb(190,20,20) else Color.DKGRAY);findViewById<TextView>(R.id.card_overdue).text="${cnt[0]}\nQuá hạn";findViewById<TextView>(R.id.card_today).text="${cnt[1]}\nHôm nay";findViewById<TextView>(R.id.card_upcoming).text="${cnt[2]}\nSắp tới";findViewById<TextView>(R.id.card_done).text="${cnt[3]}\nĐã hoàn thành";val total=pending+cnt[3];findViewById<ProgressBar>(R.id.progress).progress=if(total==0)0 else cnt[3]*100/total;findViewById<TextView>(R.id.update_time).text="Cập nhật: "+SimpleDateFormat("dd/MM HH:mm",Locale("vi")).format(Date());DailyWidget.updateAll(this);findViewById<TextView>(R.id.stats_text).text="TẤT CẢ\nQuá hạn: ${cnt[0]} • Hôm nay: ${cnt[1]} • Sắp tới: ${cnt[2]} • Hoàn thành: ${cnt[3]}\n\nDPC\nChưa hoàn thành: ${dpc[0]+dpc[1]+dpc[2]} • Hoàn thành: ${dpc[3]}\n\nGIA TÂN\nChưa hoàn thành: ${gt[0]+gt[1]+gt[2]} • Hoàn thành: ${gt[3]}"
  val all=TaskStore.tasks(this)
  all.filter{(filter=="ALL"||it.group==filter)&&(showDone.isChecked||!it.done)}.sortedWith(compareBy<Task>{it.done}.thenBy{it.whenMs}).forEach{t->
   val overdue=!t.done&&t.whenMs<System.currentTimeMillis(); val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(dp(14),dp(12),dp(14),dp(10))
   val bg=GradientDrawable(); bg.cornerRadius=dp(14).toFloat(); bg.setColor(if(overdue)Color.rgb(255,242,242) else Color.WHITE); bg.setStroke(dp(1),if(t.group=="Gia Tân")Color.rgb(204,232,213) else Color.rgb(213,226,241)); box.background=bg
   val lp=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT); lp.setMargins(0,dp(6),0,dp(6)); box.layoutParams=lp
   val tag=TextView(this); tag.text="${if(t.group=="Gia Tân")"GIA TÂN" else "DPC"}   •   ${t.code}"; tag.textSize=12f; tag.setTextColor(if(t.group=="Gia Tân")Color.rgb(36,138,75) else Color.rgb(13,95,166)); tag.setTypeface(null,android.graphics.Typeface.BOLD); box.addView(tag)
   val tv=TextView(this); tv.text="${t.title}${if(t.area.isBlank())"" else "\n${t.area}"}"; tv.textSize=16f; tv.setTextColor(Color.rgb(37,54,74)); tv.setTypeface(null,android.graphics.Typeface.BOLD); tv.setPadding(0,dp(5),0,dp(3)); box.addView(tv)
   val meta=TextView(this); meta.text="${if(overdue)"QUÁ HẠN • " else ""}Ưu tiên ${t.priority} • ${f.format(Date(t.whenMs))}${if(!t.done)" • ${remainingText(t.whenMs)}" else " • ✓ Hoàn thành"}"; meta.textSize=12f; meta.setTextColor(if(overdue)Color.rgb(180,35,35) else Color.rgb(100,116,139)); box.addView(meta)
   val b=Button(this); b.text=if(t.done)"Xóa CV" else "✓ Hoàn thành"; b.isAllCaps=false; b.textSize=12f; b.setOnClickListener{if(t.done)deleteOne(t) else complete(t)}; box.addView(b); list.addView(box)
  }
  fun addHomeGroup(label:String,groupName:String,color:Int){
   val groupTasks=all.filter{!it.done&&it.group==groupName}.sortedBy{it.whenMs}; if(groupTasks.isEmpty()) return
   val head=TextView(this); head.text="$label  •  ${groupTasks.size} CV"; head.textSize=13f; head.setTextColor(color); head.setTypeface(null,android.graphics.Typeface.BOLD); head.setPadding(dp(2),dp(9),0,dp(3)); homeList.addView(head)
   groupTasks.take(3).forEach{t->
    val overdue=t.whenMs<System.currentTimeMillis(); val h=TextView(this); h.text="${t.code}  ·  ${t.title}${if(t.area.isBlank())"" else "\n${t.area}"}\n${if(overdue)"Quá hạn" else remainingText(t.whenMs)} • Ưu tiên ${t.priority}"; h.textSize=14f; h.setTextColor(if(overdue)Color.rgb(180,35,35) else Color.rgb(37,54,74)); h.setPadding(dp(13),dp(10),dp(13),dp(10)); val hb=GradientDrawable(); hb.cornerRadius=dp(12).toFloat(); hb.setColor(if(overdue)Color.rgb(255,242,242) else Color.WHITE); hb.setStroke(dp(1),if(overdue)Color.rgb(245,190,190) else Color.rgb(225,232,240)); h.background=hb; val hlp=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT); hlp.setMargins(0,dp(3),0,dp(4)); h.layoutParams=hlp; homeList.addView(h)
   }
   if(groupTasks.size>3){val more=TextView(this); more.text="+ ${groupTasks.size-3} CV khác"; more.textSize=12f; more.setTextColor(color); more.setPadding(dp(8),dp(2),0,dp(4)); homeList.addView(more)}
  }
  addHomeGroup("DPC","DPC",Color.rgb(13,95,166)); addHomeGroup("GIA TÂN","Gia Tân",Color.rgb(36,138,75))
 }
 fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}
